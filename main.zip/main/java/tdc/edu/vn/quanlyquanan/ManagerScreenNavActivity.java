package tdc.edu.vn.quanlyquanan;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import tdc.edu.vn.quanlyquanan.data_models.User;

public class ManagerScreenNavActivity extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener {

    private ActionBarDrawerToggle drawerToggle;
    private DrawerLayout drawerLayout;
    ViewFlipper viewFlipper;
    private long backPressedTime;
    private ArrayList<Integer> listImgViewFlipper;
    Animation in, out;
    private Intent intent;
    String USERS = "Users";//Realtime Database Users node chứa thông tin user
    private String empName = "";
    private String email;
    private String imgURL = "";
    private String logoutMessage = "Bạn muốn đăng xuất?";
    private String backPressMessage = "Nhấn 2 lần để đăng xuất";
    public static TextView tvEmpName;
    public static TextView tvEmail;
    public static CircleImageView imgURLEmp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_admin_nav_with_layout);

        Button btnManageTable = (Button) findViewById(R.id.btnManageTable);
        Button btnManagaUser = (Button) findViewById(R.id.btnManageUser);
        Button btnViewMenu = (Button) findViewById(R.id.btnManageItem);
        viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipperAdmin);
        drawerLayout = findViewById(R.id.nav_drawerAdmin);
        slideViewFlipper();

        btnManageTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManagerScreenNavActivity.this, ViewTableListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        btnManagaUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManagerScreenNavActivity.this, ManageUserActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        btnViewMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManagerScreenNavActivity.this, ViewMenuActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.openDrawer, R.string.closeDrawer);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        intent = new Intent(ManagerScreenNavActivity.this, EmployeeMenuActivity.class);
        intent = getIntent();
        Bundle dataBundle = intent.getBundleExtra("dataEmp");
        empName = dataBundle.getString("empName");
        email = dataBundle.getString("email");
        imgURL = dataBundle.getString("imgURL");

        //Navigation
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View viewHeader = navigationView.getHeaderView(0);
        tvEmail = viewHeader.findViewById(R.id.tvEmailEmp);
        tvEmpName = viewHeader.findViewById(R.id.tvEmpName);
        imgURLEmp = viewHeader.findViewById(R.id.imgEmp);


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        DrawerLayout drawerLayout = findViewById(R.id.nav_drawerAdmin);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            drawerLayout.openDrawer(GravityCompat.START);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        switch (id) {
            case R.id.ic_changePass:
                this.intent.setClass(ManagerScreenNavActivity.this, ChangePassActivity.class);
                this.intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(this.intent);
                break;
            case R.id.ic_logout:
                logout();
                break;
            case R.id.ic_iforRestaurant:
                this.intent.setClass(ManagerScreenNavActivity.this, InforRestaurantActivity.class);
                this.intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(this.intent);
                break;
            case R.id.ic_inforApp:
                this.intent.setClass(ManagerScreenNavActivity.this, InforAppActivity.class);
                this.intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(this.intent);
                break;
            case R.id.ic_perInfor:
                this.intent.setClass(ManagerScreenNavActivity.this, PersonalyInforAdminActivity.class);
                this.intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(this.intent);
                break;
            default:
                break;
        }
        return false;
    }

    @Override
    public void onBackPressed() {

        if(backPressedTime + 2000 > System.currentTimeMillis()){
            logout();
        }else{
            Toast.makeText(this, backPressMessage, Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    private void slideViewFlipper() {
        listImgViewFlipper = new ArrayList<Integer>();
        listImgViewFlipper.add(R.drawable.v1);
        listImgViewFlipper.add(R.drawable.v2);
        listImgViewFlipper.add(R.drawable.v3);
        listImgViewFlipper.add(R.drawable.v4);
        for (int i = 0; i < listImgViewFlipper.size(); i++) {
            ImageView imageView = new ImageView(this);
            imageView.setImageBitmap(loadLagreImage(listImgViewFlipper.get(i),200,200));
            viewFlipper.addView(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }

        viewFlipper.setFlipInterval(3000);
        viewFlipper.setAutoStart(true);
        in = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        out = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        viewFlipper.setInAnimation(in);
        viewFlipper.setOutAnimation(out);
    }

    public Bitmap loadLagreImage(int imageID, int targetHeight, int targetWidth){
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(getResources(),imageID,options);
        final int originalHeight = options.outHeight;
        final int originalWidth = options.outWidth;
        int inSampleSize = 1;
        while (originalHeight / (inSampleSize*2) > targetHeight && (originalWidth / (inSampleSize*2) > targetWidth)){
            inSampleSize *= 2;
        }
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(getResources(),imageID,options);
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadEmpInfo();
    }

    private void logout(){
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage(logoutMessage)
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        intent.setClass(ManagerScreenNavActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }

    private void loadEmpInfo(){
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String uID = user.getUid();

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference uIDRef = rootRef.child(USERS).child(uID);

        uIDRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User tempUser = dataSnapshot.getValue(User.class);
                Picasso.get().load(tempUser.getImgURL()).into(imgURLEmp);
                tvEmail.setText(tempUser.getEmail());
                tvEmpName.setText(tempUser.getEmpName());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}