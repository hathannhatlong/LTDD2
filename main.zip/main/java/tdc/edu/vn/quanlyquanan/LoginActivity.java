package tdc.edu.vn.quanlyquanan;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GetTokenResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;
import tdc.edu.vn.quanlyquanan.data_models.User;

public class LoginActivity extends AppCompatActivity {

    private Intent intent;
    private FirebaseAuth mAuth;
    FirebaseDatabase mFirebase;
    DatabaseReference mRef;
    private ProgressDialog dialog;
    DataSnapshot ds;
    EditText edtEmail;
    TextInputLayout edtPassword;
    TextView tvMesseage;
    Button btnLogin,btnCustomerRes;
    String MANAGER = "Manager";
    String EMPLOYEE = "Employee";
    String CUSTOMER = "Customer";
    String USERS = "Users";
    private User tempUser;
    ////
    DinnerTable dinnerTable;
    ArrayList<FoodnDrink> listFood;
    String ENABLE = "ENABLE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        intent = new Intent(LoginActivity.this, ManagerScreenActivity.class);
        dialog = new ProgressDialog(this);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtPassword = (TextInputLayout) findViewById(R.id.edtPassword);
        tvMesseage = findViewById(R.id.tvMesseage);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnCustomerRes = (Button)findViewById(R.id.btnCusRegisterlayoutlogin);

        mAuth = FirebaseAuth.getInstance();

        btnLogin.setOnClickListener(onLoginClicked);
        btnCustomerRes.setOnClickListener(onRegisterClicked);
        mFirebase = FirebaseDatabase.getInstance();
        mRef = mFirebase.getReference();



    }

    @Override
    protected void onResume() {
        if(!checkInternet()){
            Dialog dialog = new Dialog(LoginActivity.this);
            dialog.setContentView(R.layout.dialog_nofi_no_internet);
            dialog.setCanceledOnTouchOutside(false);
            dialog.setTitle("Not Connect Internet");
            Button btnCheckInternet = dialog.findViewById(R.id.btnCheckInternet);
            btnCheckInternet.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            dialog.show();
        }
        super.onResume();
    }

    private boolean checkInternet(){
        boolean have_Wifi = false;
        boolean have_MobileData = false;

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo[] networkInfos = connectivityManager.getAllNetworkInfo();

        for (NetworkInfo info : networkInfos){
            if(info.getTypeName().equalsIgnoreCase("WIFI")){
                if (info.isConnected())
                    have_Wifi = true;
            }

            if(info.getTypeName().equalsIgnoreCase("MOBILE")){
                if (info.isConnected())
                    have_MobileData = true;
            }
        }

        return have_Wifi||have_MobileData;
    }

    private View.OnClickListener onRegisterClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            intent.setClass(LoginActivity.this, CustomerSignupActivity.class);
            startActivity(intent);
        }
    };

    private View.OnClickListener onLoginClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            dialog.setMessage("Đang kiểm tra tài khoản");
            dialog.show();
            if(edtEmail.getText().toString().isEmpty() && edtPassword.getEditText().getText().toString().isEmpty()){
                dialog.dismiss();
                tvMesseage.setText("Vui Lòng Nhập Email và Password");
            }else if(edtPassword.getEditText().getText().toString().isEmpty() || edtEmail.getText().toString().isEmpty()){
                dialog.dismiss();
                tvMesseage.setText("Vui Lòng Nhập Email hoặc Password");
            }else{
                String email = edtEmail.getText().toString().trim();
                final String password = edtPassword.getEditText().getText().toString().trim();
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            dialog.dismiss();
                            tvMesseage.setText("");
                            //finish();
                            final FirebaseUser user = mAuth.getCurrentUser();
                            final String uID = user.getUid();

                            DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
                            DatabaseReference uIDRef = rootRef.child(USERS).child(uID);

                            uIDRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    String role = "";
                                    User tempUser = dataSnapshot.getValue(User.class);
                                    role = tempUser.getRole();
                                    Log.d("Role", role);
                                    if (role.equals(MANAGER) && tempUser.getStatus().equals(ENABLE)) {
                                        intent.setClass(LoginActivity.this, ManagerScreenNavActivity.class);
                                        Bundle data = new Bundle();
                                        data.putString("empName",tempUser.getEmpName());
                                        data.putString("email",tempUser.getEmail());
                                        data.putString("password",password);
                                        data.putString("role",tempUser.getRole());
                                        data.putString("imgURL",tempUser.getImgURL());
                                        data.putString("uID",tempUser.getuID());
                                        intent.putExtra("dataEmp",data);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                        startActivity(intent);
                                        finish();
                                    }else if(role.equals(EMPLOYEE) && tempUser.getStatus().equals(ENABLE)) {

                                        intent.setClass(LoginActivity.this, MainEmployeeActivity.class);
                                        Bundle data = new Bundle();
                                        data.putString("empName", tempUser.getEmpName());
                                        data.putString("email", tempUser.getEmail());
                                        data.putString("password", password);
                                        data.putString("role", tempUser.getRole());
                                        data.putString("imgURL", tempUser.getImgURL());
                                        data.putString("uID", tempUser.getuID());
                                        intent.putExtra("dataEmp", data);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                        startActivity(intent);
                                        finish();
                                    }else if (role.equals(CUSTOMER) && tempUser.getStatus().equals(ENABLE)){
                                        intent.setClass(LoginActivity.this, HomepagerActivity.class);
                                        Bundle data = new Bundle();
                                        data.putString("empName",tempUser.getEmpName());
                                        data.putString("email",tempUser.getEmail());
                                        data.putString("password",password);
                                        data.putString("role",tempUser.getRole());
                                        data.putString("imgURL",tempUser.getImgURL());
                                        data.putString("uID",tempUser.getuID());
                                        intent.putExtra("dataEmp",data);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                        startActivity(intent);
                                        finish();
                                    }else{
                                        tvMesseage.setText("Sai Tài Khoản hoặc Mật Khẩu");
                                    }
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                            edtEmail.setText("");
                            edtPassword.getEditText().setText("");
                        }else{
                            dialog.dismiss();
                            tvMesseage.setText("Sai Email hoặc Password");
                        }
                    }
                });
            }

        }
    };
}
