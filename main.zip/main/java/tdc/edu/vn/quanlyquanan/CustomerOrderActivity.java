package tdc.edu.vn.quanlyquanan;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.allyants.notifyme.NotifyMe;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;
import tdc.edu.vn.quanlyquanan.data_models.Order;

public class CustomerOrderActivity extends AppCompatActivity {

    private ArrayList<Order> data;

    String ORDER = "Order";
    DatabaseReference mOrderDB;
    ValueEventListener mDBListener;

    String dateBookTable;
    String timeBookTable,timeNoty;
    Calendar cal,calNoty;
    TextView txtDate, txtTime, txtName,txtEmail,txtTable,txtPeople;
    Button btnOrder,btnDate, btnTime;


    ListView lv_menu;

    ArrayList<FoodnDrink> arrOrder = new ArrayList<FoodnDrink>();
    ArrayAdapter<FoodnDrink> adapter = null;

    Intent intent;
    String empName,email,imgURL,CustomerId, soBan;
    String People;

    Date date,time,dateDefault,timeDefault;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_order_layout);
        setControl();
        addEvent();
        getDefaultInfor();
        intent = getIntent();
        Bundle dataBundle = intent.getBundleExtra("dataEmp");
        empName = dataBundle.getString("empName");
        email = dataBundle.getString("email");
        imgURL = dataBundle.getString("imgURL");
        CustomerId = dataBundle.getString("uID");
        soBan = dataBundle.getString("soBan");

        txtName.setText(empName);
        txtEmail.setText(email);
        txtTable.setText(Integer.parseInt(soBan)+"");


    }

    public void setControl(){
        txtDate = findViewById(R.id.txtdate);
        txtTime = findViewById(R.id.txttime);
        btnDate = findViewById(R.id.btndate);
        btnTime = findViewById(R.id.btntime);
        btnOrder = findViewById(R.id.btnorder);
        txtName = findViewById(R.id.txtCustomerNameOrder);
        txtEmail = findViewById(R.id.txtCustomerEmailOrder);
        txtTable = findViewById(R.id.txtTableOrder);
        txtPeople = findViewById(R.id.txtPeople);
    }

    /**
     * Hàm lấy các thông số mặc định khi lần đầu tiền chạy ứng dụng
     */
    public void getDefaultInfor() {
        //lấy ngày hiện tại của hệ thống
        cal = Calendar.getInstance();
        SimpleDateFormat dft = null;
        //Định dạng ngày / tháng /năm
        dft = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String strDate = dft.format(cal.getTime());
        //hiển thị lên giao diện
        txtDate.setText(strDate);
        //Định dạng giờ phút am/pm
        dft = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String strTime = dft.format(cal.getTime());
        //đưa lên giao diện
        txtTime.setText(strTime);
        //lấy giờ theo 24 để lập trình theo Tag
        dft = new SimpleDateFormat("HH:mm", Locale.getDefault());
        txtTime.setTag(dft.format(cal.getTime()));

        //gán cal.getTime() cho ngày hoàn thành và giờ hoàn thành

        date = cal.getTime();
        time = cal.getTime();

        dateBookTable = txtDate.getText()+"";
        timeBookTable = txtTime.getText()+"";

        dateDefault = cal.getTime();
        timeDefault = cal.getTime();
    }

    public void addEvent() {
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDialog();

            }
        });
        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePickerDialog();

            }
        });
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (date.before(dateDefault)||time.before(timeDefault)) {
                    Toast.makeText(CustomerOrderActivity.this, "Thời gian không phù hợp", Toast.LENGTH_SHORT).show();
                }else{
                    newOrderFood();
                    intent.setClass(CustomerOrderActivity.this,HomepagerActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
    /**
     * Hàm xử lý đưa công việc vào ListView khi nhấn nút Thêm Công việc
     */
    public void newOrderFood() {
        dateBookTable = txtDate.getText().toString();
        timeBookTable = txtTime.getText().toString();
        mOrderDB = FirebaseDatabase.getInstance().getReference(ORDER);
        People = (txtPeople.getText().toString());
        String id = mOrderDB.push().getKey();
        Order tmp = new Order();
        tmp.setId(id);
        tmp.setTableid(Integer.parseInt(soBan)+"");
        tmp.setGmailCustomer(email);
        tmp.setNumberPeople(People);
        tmp.setBillId("");
        tmp.setDateBookTable(dateBookTable);
        tmp.setTimeBookTable(timeBookTable);
        tmp.setStatus("Order");
        data = new ArrayList<>();
        mOrderDB.child(id).setValue(tmp).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(CustomerOrderActivity.this, "Đặt bàn thành công", Toast.LENGTH_SHORT).show();
            }
        });

        //Thông báo tạo công việc thành công
        NotifyMe success = new NotifyMe.Builder(getApplicationContext())
                .title("Đặt bàn thành công!")
                .content("Nội dung: Bạn Có lịch hẹn vào ngày "+dateBookTable+" lúc "+ timeBookTable + "\n" +" Tại bàn số: "+ soBan+"\n"+"Số người: "+ People)
                .color(255, 0, 0, 255)
                .led_color(255, 255, 255, 255)


                .key("test")
                .addAction(new Intent(), "Dismiss", true, false)

                .large_icon(R.drawable.ic_logo_restaurant)
                .build();

        //Thông báo có lịch hẹn trước 15 phút
        NotifyMe popup = new NotifyMe.Builder(getApplicationContext())
                .title("Đặt bàn")
                .content("Nội dung: Bạn Có lịch hẹn vào ngày "+dateBookTable+" lúc "+ timeBookTable + "\n" +" Tại bàn số: "+ soBan+"\n"+"Số người: "+ People)
                .color(255, 0, 0, 255)
                .led_color(255, 255, 255, 255)
                .time(time)
                .time(date)
                .key("test")
                .addAction(new Intent(), "Dismiss", true, false)

                .large_icon(R.drawable.ic_launcher_foreground)
                .build();
    }

    /**
     * Hàm hiển thị DatePicker dialog
     */
    public void showDatePickerDialog() {
        DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year,
                                  int monthOfYear,
                                  int dayOfMonth) {
                //Mỗi lần thay đổi ngày tháng năm thì cập nhật lại TextView Date
                txtDate.setText(
                        (dayOfMonth) + "/" + (monthOfYear + 1) + "/" + year);
                //Lưu vết lại biến ngày hoàn thành
                cal.set(year, monthOfYear, dayOfMonth);
                date = cal.getTime();

            }
        };
        //các lệnh dưới này xử lý ngày giờ trong DatePickerDialog
        //sẽ giống với trên TextView khi mở nó lên
        String s = txtDate.getText() + "";
        dateBookTable = txtDate.getText()+"";
        String strArrtmp[] = s.split("/");
        int ngay = Integer.parseInt(strArrtmp[0]);
        int thang = Integer.parseInt(strArrtmp[1]) - 1;
        int nam = Integer.parseInt(strArrtmp[2]);
        DatePickerDialog pic = new DatePickerDialog(
                CustomerOrderActivity.this,
                callback, nam, thang, ngay);
        pic.setTitle("Chọn ngày hoàn thành");
        pic.show();
    }
    public void showTimePickerDialog() {
        TimePickerDialog.OnTimeSetListener callback = new TimePickerDialog.OnTimeSetListener() {
            public void onTimeSet(TimePicker view,
                                  int hourOfDay, int minute) {
                //Xử lý lưu giờ và AM,PM
                String s = hourOfDay + ":" + minute;
                int hourTam = hourOfDay;
                if (hourTam > 12)
                    hourTam = hourTam - 12;
                txtTime.setText
                        (hourTam + ":" + minute + (hourOfDay > 12 ? " PM" : " AM"));
                //lưu giờ thực vào tag
                txtTime.setTag(s);
                //lưu vết lại giờ vào hourFinish
                cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                cal.set(Calendar.MINUTE, minute);
                time = cal.getTime();

            }
        };
        //các lệnh dưới này xử lý ngày giờ trong TimePickerDialog
        //sẽ giống với trên TextView khi mở nó lên
        String s = txtTime.getTag() + "";
        timeBookTable = txtTime.getText()+"";
        String strArr[] = s.split(":");
        int gio = Integer.parseInt(strArr[0]);
        int phut = Integer.parseInt(strArr[1]);
        TimePickerDialog time = new TimePickerDialog(
                CustomerOrderActivity.this,
                callback, gio, phut, true);
        time.setTitle("Chọn giờ hoàn thành");
        time.show();
    }
}
