package tdc.edu.vn.quanlyquanan;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuInflater;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import tdc.edu.vn.quanlyquanan.adapters.MyRecyclerViewAdapterMenuMonAn;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;
import tdc.edu.vn.quanlyquanan.data_models.Order;

public class HomepagerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private RecyclerView recyclerViewMenu;
    private ArrayList<DinnerTable> listBanBan;
    private ArrayList<FoodnDrink> data;
    private ArrayList<Order> listOrder;
    TextView tvMaBan;
    TextView tvEmpName;
    TextView tvEmail;
    CircleImageView imgURLEmp;
    String empName = "";
    String email;
    String imgURL = "";
    String id = "";
    String phone = "";

    private MyRecyclerViewAdapterMenuMonAn adapter;

    private Intent intent;
    private int soBan;
    private int positionMenu;

    //FireBase
    DatabaseReference mFoodnDrinkDatabase;
    DatabaseReference mData;
    FirebaseStorage mStorage;
    StorageReference mImageStorage;
    ValueEventListener mDBListener;
    String FOODNDRINK = "FoodnDrink";
    String UPLOADS = "uploads";
    String TABLE = "DinnerTable";
    //ORDER
    String ORDER = "Order";
    DatabaseReference mOrderDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepager_layout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(HomepagerActivity.this,CustomerOrderTableChoiseActivity.class);
                Bundle data = new Bundle();
                data.putString("empName",empName);
                data.putString("email",email);
                data.putString("uID",id);
                data.putString("phone",phone);
                intent.putExtra("dataEmp",data);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
//               Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        View viewHeader = navigationView.getHeaderView(0);

        intent = getIntent();
        final Bundle dataBundle = intent.getBundleExtra("dataEmp");
        empName = dataBundle.getString("empName");
        email = dataBundle.getString("email");
        imgURL = dataBundle.getString("imgURL");
        id = dataBundle.getString("uID");
        phone = dataBundle.getString("phone");
        tvEmail = viewHeader.findViewById(R.id.txtCustomerName);
        tvEmpName = viewHeader.findViewById(R.id.txtCustomerEmail);
        imgURLEmp = viewHeader.findViewById(R.id.imageCustomer);
        Picasso.get().load(imgURL).into(imgURLEmp);
        tvEmail.setText(email);
        tvEmpName.setText(empName);
        imgURLEmp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.setClass(HomepagerActivity.this, FullPhotoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });


        //Tao Order

        //Load Danh Sach Mon An
        mData = FirebaseDatabase.getInstance().getReference();
        recyclerViewMenu = findViewById(R.id.recyclerViewHome_menu);
        final Dialog dialog = new Dialog(HomepagerActivity.this);


        //Đổ data
        data = new ArrayList<FoodnDrink>();
        listOrder = new ArrayList<Order>();

        mData.child(ORDER).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        listBanBan = new ArrayList<DinnerTable>();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerViewMenu.setLayoutManager(layoutManager);
        adapter = new MyRecyclerViewAdapterMenuMonAn(R.layout.cardview_menu_employee_layout,data);
        adapter.setmClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"Item Is Checked", Toast.LENGTH_SHORT).show();
            }
        });
        //Firebase

        mFoodnDrinkDatabase = FirebaseDatabase.getInstance().getReference(FOODNDRINK);
        mStorage = FirebaseStorage.getInstance();
        mImageStorage = FirebaseStorage.getInstance().getReference(UPLOADS);
        mDBListener = mFoodnDrinkDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data.clear();//Clear arraylist to avoid duplication
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    FoodnDrink tmpItem = ds.getValue(FoodnDrink.class);
                    data.add(tmpItem);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        recyclerViewMenu.setAdapter(adapter);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.homepager, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search_customer);

        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setQueryHint(getString(R.string.hintSearch));
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                List<FoodnDrink> foodnDrinks = new ArrayList<>();
                for(FoodnDrink foodnDrink : data){
                    if(foodnDrink.getName().toLowerCase().contains(newText.toLowerCase())){
                        foodnDrinks.add(foodnDrink);
                    }
                }
                adapter.searchItem(foodnDrinks);
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_search_customer) {
//            return true;
//        }
      return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        switch (id) {
            case R.id.ic_changePassCustomer:
                changePass();
                break;
            case R.id.ic_logoutCustomer:
                logout();
                break;
            case R.id.ic_iforRestaurantCustomer:
                intent.setClass(HomepagerActivity.this, InforRestaurantActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                break;
            case R.id.ic_inforAppCustomer:
                intent.setClass(HomepagerActivity.this, InforAppActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                break;
            case R.id.ic_perInforCustomer:
                intent.setClass(HomepagerActivity.this, CustomerInformationActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                break;
            default:
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private void changePass() {
        intent.setClass(HomepagerActivity.this, ChangePassActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }

    private void logout(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Bạn có chắc chắn muốn đăng xuất không?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        intent.setClass(HomepagerActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }

}
