package tdc.edu.vn.quanlyquanan;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class AddMenuItemActivity extends AppCompatActivity {

    EditText edtItemName, edtItemPrice;
    Button btnAddNewMenuItem, btnChooseImage;
    ProgressBar addItemProgessBar;
    ImageView imgUpload;
    Uri imgUri;

    String FOODNDRINK = "FoodnDrink";//Realtime Database FoodnDrink node
    String UPLOADS = "uploads";//Firebase Storage uploads node

    static final int IMAGE_REQUEST = 1;

    StorageReference mImageStorage;
    DatabaseReference mFoodnDrinkDatabase;
    StorageTask uploadTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_menu_item_layout);

        edtItemPrice = (EditText) findViewById(R.id.edtItemPrice);
        edtItemName = (EditText) findViewById(R.id.edtItemName);
        btnAddNewMenuItem = (Button) findViewById(R.id.btnAddMenuItem);
        btnChooseImage = (Button) findViewById(R.id.btnUploads);
        imgUpload = (ImageView) findViewById(R.id.imgUpload);
        addItemProgessBar = (ProgressBar) findViewById(R.id.addItemProgessBar);

        btnChooseImage.setOnClickListener(onChooseImageClicked);
        btnAddNewMenuItem.setOnClickListener(onAddNewItemClicked);

        mImageStorage = FirebaseStorage.getInstance().getReference(UPLOADS);
        mFoodnDrinkDatabase = FirebaseDatabase.getInstance().getReference(FOODNDRINK);
    }

    private View.OnClickListener onAddNewItemClicked = new View.OnClickListener() {
        String id, itemName, imgURL;
        double itemPrice;
        FoodnDrink tmpItem;
        @Override
        public void onClick(View v) {
            if(uploadTask != null && uploadTask.isInProgress()){
                Toast.makeText(AddMenuItemActivity.this, "Đang thêm món vui lòng chờ", Toast.LENGTH_SHORT).show();
            }else {
                id = mFoodnDrinkDatabase.push().getKey();
                final StorageReference fileRef;
                if(TextUtils.isEmpty(edtItemName.getText())){
                    edtItemName.setError("Vui lòng nhập tên món");
                    edtItemName.requestFocus();
                    return;
                }else{
                    itemName = edtItemName.getText().toString().trim();
                }
                if(TextUtils.isEmpty(edtItemPrice.getText())){
                    edtItemPrice.setError("Vui lòng nhập giá món");
                    edtItemPrice.requestFocus();
                    return;
                }else{
                    itemPrice = Float.parseFloat(edtItemPrice.getText().toString());
                }
                if(imgUri == null){
                    Toast.makeText(AddMenuItemActivity.this,"Vui lòng chọn hình món ăn",Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    fileRef = mImageStorage.child(System.currentTimeMillis() + "." + getFileExtension(imgUri));
                }

                //Get progess percent for progess bar, get Image URL, toast message if upload fail
                uploadTask = fileRef.putFile(imgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        //Delay progress bar reset for visual confirmation
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                addItemProgessBar.setProgress(0);
                            }
                        }, 500);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddMenuItemActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        addItemProgessBar.setProgress((int) progress);
                    }
                }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                        while(!uriTask.isComplete());
                        Uri downloadUrl = uriTask.getResult();
                        imgURL = downloadUrl.toString();
                        tmpItem = new FoodnDrink();
                        //Add data into object
                        tmpItem.setId(id);
                        tmpItem.setName(itemName);
                        tmpItem.setPrice(itemPrice);
                        tmpItem.setImgURL(imgURL);
                        //Upload object
                        mFoodnDrinkDatabase.child(id).setValue(tmpItem);
                        //Clear views
                        edtItemName.setText("");
                        edtItemPrice.setText("");
                        imgUpload.setImageDrawable(null);
                        edtItemName.requestFocus();
                    }
                });
                Toast.makeText(AddMenuItemActivity.this,"Thêm món thành công", Toast.LENGTH_SHORT).show();
            }
        }
    };

    private View.OnClickListener onChooseImageClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent, IMAGE_REQUEST);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){
            imgUri = data.getData();

            Picasso.get().load(imgUri).into(imgUpload);
        }
    }

    private String getFileExtension(Uri uri){
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }
}