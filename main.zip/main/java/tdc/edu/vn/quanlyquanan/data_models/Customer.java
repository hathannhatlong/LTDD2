package tdc.edu.vn.quanlyquanan.data_models;

public class Customer {
    private String cusEmail,cusName,cusPhone, cusRole,uID,imgURL;

    public Customer(String cusEmail, String cusName, String cusPhone, String cusRole, String uID, String imgURL) {
        this.cusEmail = cusEmail;
        this.cusName = cusName;
        this.cusPhone = cusPhone;
        this.cusRole = cusRole;
        this.uID = uID;
        this.imgURL = imgURL;
    }

    public Customer() {
    }

    public String getCusEmail() {
        return cusEmail;
    }

    public void setCusEmail(String cusEmail) {
        this.cusEmail = cusEmail;
    }

    public String getCusName() {
        return cusName;
    }

    public void setCusName(String cusName) {
        this.cusName = cusName;
    }

    public String getCusPhone() {
        return cusPhone;
    }

    public void setCusPhone(String cusPhone) {
        this.cusPhone = cusPhone;
    }

    public String getCusRole() {
        return cusRole;
    }

    public void setCusRole(String cusRole) {
        this.cusRole = cusRole;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }
}
