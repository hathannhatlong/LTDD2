package tdc.edu.vn.quanlyquanan.data_models;

public class User {
    String email;
    String empName;
    String role;
    String uID;
    String imgURL;



    String status;
    public User(String email, String empName, String role, String uID, String imgURL) {
        this.uID = uID;
        this.email = email;
        this.empName = empName;
        this.role = role;
        this.imgURL = imgURL;
        this.status = "ENABLE";
    }

    public User() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }
    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
