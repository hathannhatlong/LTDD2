package tdc.edu.vn.quanlyquanan.data_models;

public class FoodnDrink {
    String id;
    String name;
    Double price;
    int amount;
    String imgURL;

    public FoodnDrink() {
    }

    public FoodnDrink(String id, String name, Double price, int amount, String imgURL) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.amount = amount;
        this.imgURL = imgURL;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    @Override
    public String toString() {
        return this.name + this.getPrice();
    }

    public Double total(){
        Double total = 0.0;
        total = this.price * this.amount;
        return total;
    }
}
