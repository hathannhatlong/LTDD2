package tdc.edu.vn.quanlyquanan.data_models;

public class Rating {
}
