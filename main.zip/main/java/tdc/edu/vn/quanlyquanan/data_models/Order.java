package tdc.edu.vn.quanlyquanan.data_models;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Order {
    private String id;
    private String tableid;
    private String gmailCustomer;
    private String numberPeople;
    private String billId;
    private String dateBookTable;
    private String timeBookTable;
    private String Status;

    public Order(String id, String tableid, String gmailCustomer, String numberPeople, String billId, String dateBookTable, String timeBookTable, String status) {
        this.id = id;
        this.tableid = tableid;
        this.gmailCustomer = gmailCustomer;
        this.numberPeople = numberPeople;
        this.billId = billId;
        this.dateBookTable = dateBookTable;
        this.timeBookTable = timeBookTable;
        Status = status;
    }

    public Order() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTableid() {
        return tableid;
    }

    public void setTableid(String tableid) {
        this.tableid = tableid;
    }

    public String getGmailCustomer() {
        return gmailCustomer;
    }

    public void setGmailCustomer(String gmailCustomer) {
        this.gmailCustomer = gmailCustomer;
    }

    public String getNumberPeople() {
        return numberPeople;
    }

    public void setNumberPeople(String numberPeople) {
        this.numberPeople = numberPeople;
    }

    public String getBillId() {
        return billId;
    }

    public void setBillId(String billId) {
        this.billId = billId;
    }

    public String getDateBookTable() {
        return dateBookTable;
    }

    public void setDateBookTable(String dateBookTable) {
        this.dateBookTable = dateBookTable;
    }

    public String getTimeBookTable() {
        return timeBookTable;
    }

    public void setTimeBookTable(String timeBookTable) {
        this.timeBookTable = timeBookTable;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    /**
     * lấy định dạng ngày
     */
    public String getDateFormat(Date d) {
        SimpleDateFormat dft = new
                SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return dft.format(d);
    }

    /**
     * lấy định dạng giờ phút
     */
    public String getHourFormat(Date d) {
        SimpleDateFormat dft = new
                SimpleDateFormat("hh:mm a", Locale.getDefault());
        return dft.format(d);
    }
}
