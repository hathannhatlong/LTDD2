package tdc.edu.vn.quanlyquanan.data_models;

import java.util.ArrayList;
import java.util.Calendar;

public class DinnerTable {
    private String id;
    private int numberTable;
    private ArrayList<FoodnDrink> listFoodnDrink;
    private String date;

    public DinnerTable(String id, int numberTable, ArrayList<FoodnDrink> listFoodnDrink, String date) {
        this.id = id;
        this.numberTable = numberTable;
        this.listFoodnDrink = listFoodnDrink;
        this.date = date;
    }

    public DinnerTable() {
    }

    public int getNumberTable() {
        return numberTable;
    }

    public void setNumberTable(int numberTable) {
        this.numberTable = numberTable;
    }

    public ArrayList<FoodnDrink> getListFoodnDrink() {
        return listFoodnDrink;
    }

    public void setListFoodnDrink(ArrayList<FoodnDrink> listFoodnDrink) {
        this.listFoodnDrink = listFoodnDrink;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Double pay(){
        Double pay = 0.0;
        for (FoodnDrink foodnDrink : listFoodnDrink){
            pay += foodnDrink.total();
        }
        return pay;
    }
}
