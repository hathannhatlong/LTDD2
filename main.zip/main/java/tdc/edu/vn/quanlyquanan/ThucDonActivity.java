package tdc.edu.vn.quanlyquanan;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;

import tdc.edu.vn.quanlyquanan.adapters.MyArrayAdapterBillPayment;
import tdc.edu.vn.quanlyquanan.adapters.ThucDonAdapter;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class ThucDonActivity extends AppCompatActivity {
    private ThucDonAdapter adapter;
    private ListView lv_ThucDon;
    private Button btnTinhTien,btnAddFood;
    private Intent intent;
    private TextView tv_soBan;

    private TextView tv_Date;
    private ArrayList<FoodnDrink> listMonAn;
    private ArrayList<DinnerTable> listDinnerTable;
    private int soBan;
    private double tongTien = 0;
    int counter = 0;

    Double exessCass = 0.0;
    Double pay = 0.0;
    Double tienThua = 0.0;
    //Firebase
    DatabaseReference mData;
    ValueEventListener mDBListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thuc_don_layout);
        AnhXa();
        intent = new Intent(ThucDonActivity.this,EmployeeMenuActivity.class);
        intent = getIntent();
        final Bundle dataBundle = intent.getBundleExtra("maBan");
        soBan = Integer.parseInt(dataBundle.getString("soBan"));
        dataBundle.remove("soBan");
        //Firebase
        mData = FirebaseDatabase.getInstance().getReference();
        listMonAn = new ArrayList<FoodnDrink>();
        listDinnerTable = new ArrayList<>();
        tv_soBan.setText("Bàn Số: " + (soBan));

        mDBListener = mData.child("DinnerTable").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listDinnerTable.clear();//Clear arraylist to avoid duplication
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    DinnerTable tmpItem = ds.getValue(DinnerTable.class);
                    listDinnerTable.add(tmpItem);
                }

                for (DinnerTable dinnerTable1 : listDinnerTable) {
                    if (dinnerTable1.getNumberTable() == soBan) {
                        listMonAn.clear();
                        tv_Date.setText(dinnerTable1.getDate());
                        for (FoodnDrink foodnDrink : dinnerTable1.getListFoodnDrink()) {
                            listMonAn.add(foodnDrink);
                        }
                    }
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        btnAddFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.setClass(ThucDonActivity.this,EmployeeMenuActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                dataBundle.putString("soBan",soBan+"");
                intent.putExtra("dataEmp", dataBundle);
                startActivity(intent);
            }
        });



        adapter = new ThucDonAdapter(ThucDonActivity.this,R.layout.list_item_thuc_don_layout,listMonAn);
        lv_ThucDon.setAdapter(adapter);

        lv_ThucDon.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> parent, final View view, final int position, final long id) {
                final Dialog dialog = new Dialog(view.getContext());
                dialog.setContentView(R.layout.dialog_edit_monan_layout);
                TextView tv_XoaMon = dialog.findViewById(R.id.tv_xoaMon);
                TextView tv_SuaMon = dialog.findViewById(R.id.tv_suaMon);
                dialog.show();
                tv_XoaMon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        AlertDialog.Builder builder = new AlertDialog.Builder(ThucDonActivity.this);
                        builder.setMessage("Bạn có chắc chắn muốn xóa " + listMonAn.get(position).getName() + " ?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        final DinnerTable table = listDinnerTable.get(soBan-1);
                                        DinnerTable editTable = new DinnerTable();
                                        ArrayList<FoodnDrink> foodnDrinks = new ArrayList<>();
                                        foodnDrinks = table.getListFoodnDrink();
                                        foodnDrinks.remove(position);
                                        editTable.setId(table.getId());
                                        editTable.setDate(table.getDate());
                                        editTable.setListFoodnDrink(foodnDrinks);
                                        editTable.setNumberTable(table.getNumberTable());
                                        mData.child("DinnerTable").child(table.getId()).setValue(editTable);
                                        adapter.notifyDataSetChanged();
                                        Toast.makeText(view.getContext(), "Món " + listMonAn.get(position).getName()+" Đã Xóa",Toast.LENGTH_SHORT).show();
                                        dialog.cancel();
                                        dialog.dismiss();
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.setCanceledOnTouchOutside(false);
                        alertDialog.show();
                    }
                });

                tv_SuaMon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final Dialog dialog = new Dialog(view.getContext());
                        dialog.setContentView(R.layout.dialog_edit_amont_food);
                        final TextView tvAmount = dialog.findViewById(R.id.tvAmount);
                        final Button btnDecrease = dialog.findViewById(R.id.btnDecrease);
                        Button btnIncrease = dialog.findViewById(R.id.btnIncrease);
                        Button btnEdit = dialog.findViewById(R.id.btnEdit);
                        Button btnCancle = dialog.findViewById(R.id.btnCancle);
                        counter = listDinnerTable.get(soBan-1).getListFoodnDrink().get(position).getAmount();
                        tvAmount.setText(counter+"");
                        dialog.setCanceledOnTouchOutside(false);

                        btnIncrease.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(counter >= 1) {
                                    btnDecrease.setEnabled(true);
                                    counter++;
                                    tvAmount.setText(counter + "");
                                }
                            }
                        });

                        btnDecrease.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if(counter <= 1){
                                    btnDecrease.setEnabled(false);
                                }else{
                                    counter--;
                                    tvAmount.setText(counter+"");
                                }

                            }
                        });

                        btnCancle.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog.dismiss();
                            }
                        });

                        btnEdit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                final DinnerTable table = listDinnerTable.get(soBan-1);
                                DinnerTable editTable = new DinnerTable();
                                ArrayList<FoodnDrink> foodnDrinks = new ArrayList<>();
                                foodnDrinks = table.getListFoodnDrink();
                                foodnDrinks.get(position).setAmount(counter);
                                editTable.setId(table.getId());
                                editTable.setDate(table.getDate());
                                editTable.setListFoodnDrink(foodnDrinks);
                                editTable.setNumberTable(table.getNumberTable());
                                mData.child("DinnerTable").child(table.getId()).setValue(editTable);
                                adapter.notifyDataSetChanged();
                                dialog.dismiss();
                            }
                        });

                        dialog.show();
                    }
                });
                return false;
            }
        });

        btnTinhTien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(ThucDonActivity.this);
                dialog.setContentView(R.layout.bill_payment_layout);
                final TextView tv_totalMoneyBill = dialog.findViewById(R.id.tv_totalMoneyBill);
                final TextView edt_moneyAdvance = dialog.findViewById(R.id.edt_moneyAdvance);
                final TextView tv_excessCash = dialog.findViewById(R.id.tv_excessCash);
                final TextView btnThanhToan = dialog.findViewById(R.id.btnThanhToan);
                final TextView btnQuayLai = dialog.findViewById(R.id.btnQuayLai);
                final ListView lv_billPayment = dialog.findViewById(R.id.lv_billPayment);
                final TextView tvNumberTable = dialog.findViewById(R.id.tv_soBan);

                tvNumberTable.setText("Bàn Số " + soBan);

                pay = listDinnerTable.get((soBan-1)).pay();



                final MyArrayAdapterBillPayment myArrayAdapterBillPayment = new MyArrayAdapterBillPayment(ThucDonActivity.this,R.layout.list_item_bill_layout,listDinnerTable.get((soBan-1)).getListFoodnDrink());
                lv_billPayment.setAdapter(myArrayAdapterBillPayment);

                tv_totalMoneyBill.setText(listDinnerTable.get((soBan-1)).pay().toString());

                btnThanhToan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(!edt_moneyAdvance.getText().toString().isEmpty()){
                            updateTable(listDinnerTable.get(soBan-1));
                            dialog.dismiss();
                            listMonAn.clear();
                            adapter.notifyDataSetChanged();
                            MainEmployeeActivity.adapter.notifyDataSetChanged();
                            intent.setClass(ThucDonActivity.this,MainEmployeeActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(intent);
                            Toast.makeText(ThucDonActivity.this, "Thanh Toán Thành Công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(ThucDonActivity.this, "Bạn Chưa Nhập Tiền Trả", Toast.LENGTH_SHORT).show();
                            edt_moneyAdvance.requestFocus();
                        }
                    }
                });

                edt_moneyAdvance.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        if(s.toString().isEmpty()){
                            tv_excessCash.setText("");
                        }else {
                            exessCass = Double.parseDouble(s.toString());
                            tienThua = exessCass - pay;
                            if(tienThua < 0)
                                tv_excessCash.setText("Ở Lại rửa chén nha em");
                            else
                                tv_excessCash.setText(tienThua.toString());
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });

                btnQuayLai.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.setTitle("Chi Tiết Hóa Đơn");
                dialog.show();
            }
        });

    }

    private void AnhXa(){
        lv_ThucDon = findViewById(R.id.lv_ThucDon);
        tv_soBan = findViewById(R.id.tv_soBan);
        btnTinhTien = findViewById(R.id.btnTinhTien);
        tv_Date = findViewById(R.id.tv_tenNhanVien);
        btnAddFood = findViewById(R.id.btnAddFood);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }



    public void updateTable(DinnerTable dinnerTable) {
        DinnerTable table = dinnerTable;
        String id = table.getId();
        ArrayList<FoodnDrink> foodnDrinks = new ArrayList<>();
        foodnDrinks.add(new FoodnDrink(id,"Rau Song",0.0,0,"https://znews-photo.zadn.vn/w660/Uploaded/sgorvz/2016_06_17/rau_song.jpg"));
        table.getListFoodnDrink().clear();
        table.setDate("");
        table.setListFoodnDrink(foodnDrinks);
        table.setId(id);
        mData.child("DinnerTable").child(table.getId()).setValue(table);
    }

}
