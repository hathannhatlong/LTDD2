package tdc.edu.vn.quanlyquanan;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import tdc.edu.vn.quanlyquanan.adapters.MyUserArrayAdapter;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;
import tdc.edu.vn.quanlyquanan.data_models.User;

public class ManageUserActivity extends AppCompatActivity {

    private DatabaseReference mUserDB;
    private String USER = "Users";// Node chứa thông tin user trong Realtime Database
    private String USERIMG = "user";// Node chứa hình user trong Firebase Storage
    private String ENABLE = "ENABLE";//Kích hoạt
    private String DISABLE = "DISABLE";//Vô hiệu
    private String DISABLE_CONFIRM = "Bạn có chắc chắn muốn vô hiệu người dùng được chọn?";//Thông báo vô hiệu tài khoản
    private String ENABLE_CONFIRM = "Bạn có chắc chắn muốn kích hoạt người dùng được chọn?";//Thông báo kích hoạt
    private String EMAILSENT = "Đã gửi email phục hồi mật khẩu đến địa chỉ email của người dùng được chọn";
    private String INCORRECTPASSWORD = "Mật khẩu xác nhận không chính xác";
    private String UPDATESUCCESS = "Cập nhật thành công";
    private ArrayList<User> data;
    private int IMAGE_REQUEST = 1;
    private Uri imgUri;
    private String MANAGER = "Manager";
    private String EMPLOYEE = "Employee";
    private String contextMenuReset = "Phục hồi mật khẩu";
    private String contextMenuEdit = "Sửa";
    private String contextMenuEnable = "Kích hoạt";
    private String contextMenuDisable = "Vô hiệu";
    private StorageTask uploadTask;
    private StorageReference storageReference;
    private ImageView imgNewImgUpload;
    private StorageReference fileRef;
    private boolean flag = false;
    private MyUserArrayAdapter adapter;
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_user_layout);

        listView = (ListView) findViewById(R.id.listView_User);
        Button btnAddNewUser = findViewById(R.id.btnAddNewUser);
        mUserDB = FirebaseDatabase.getInstance().getReference(USER);
        data = new ArrayList<>();

        adapter = new MyUserArrayAdapter(this,R.layout.list_user_layout, data);

        listView.setAdapter(adapter);

        mUserDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data.clear();
                User tmp;
                for (DataSnapshot ds : dataSnapshot.getChildren())
                {
                    tmp = ds.getValue(User.class);
                    data.add(tmp);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        registerForContextMenu(listView);
        storageReference = FirebaseStorage.getInstance().getReference(USERIMG);

        btnAddNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ManageUserActivity.this, SignupActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("Select Action");
        menu.add(Menu.NONE,1,1,contextMenuEdit);
        menu.add(Menu.NONE,2,2,contextMenuDisable);
        menu.add(Menu.NONE,3,3,contextMenuEnable);
        menu.add(Menu.NONE,4,4,contextMenuReset);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if(item.getTitle().equals(contextMenuDisable)){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int index = info.position;
            final User user = data.get(index);
            if(user.getStatus().equals(DISABLE)){
                Toast.makeText(this, "Trạng thái người dùng được chọn đã là vô hiệu", Toast.LENGTH_SHORT).show();
            }else{
                final String selectedItemID = user.getuID();
                final boolean flag = checkCurrentUser(selectedItemID);

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.delete_confirm_dialog, null);
                //Set message base on seleted action
                TextView message = dialogView.findViewById(R.id.confirm_dialog_message);
                if(!flag){
                    message.setText(DISABLE_CONFIRM);
                }else{
                    message.setText("Tài khoản đang sử dụng sẽ bị đăng xuất nếu tiếp tục");
                }
                dialogBuilder.setView(dialogView);
                final Button btnDeleteConfirm = (Button) dialogView.findViewById(R.id.btnDeleteConfirm);
                final Button btnDeleteCancel = (Button) dialogView.findViewById(R.id.btnDeleteCancel);

                final AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();

                btnDeleteConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!flag){
                            user.setStatus(DISABLE);
                            mUserDB.child(selectedItemID).setValue(user);
                            Toast.makeText(ManageUserActivity.this, "Vô hiệu người dùng thành công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }else{
                            mUserDB.child(selectedItemID).setValue(user);
                            finish();
                            FirebaseAuth.getInstance().signOut();
                            Intent intent = new Intent(ManageUserActivity.this, LoginActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                        }
                    }
                });

                btnDeleteCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }
            return true;
        }

        if(item.getTitle().equals(contextMenuEnable)){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int index = info.position;
            final User user = data.get(index);
            final String selectedItemID = user.getuID();
            if(user.getStatus().equals(ENABLE)){
                Toast.makeText(this, "Trạng thái người dùng được chọn đã là kích hoạt", Toast.LENGTH_SHORT).show();
            }else{

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.delete_confirm_dialog, null);
                //Set message base on seleted action
                TextView message = dialogView.findViewById(R.id.confirm_dialog_message);
                message.setText(ENABLE_CONFIRM);
                dialogBuilder.setView(dialogView);
                final Button btnDeleteConfirm = (Button) dialogView.findViewById(R.id.btnDeleteConfirm);
                final Button btnDeleteCancel = (Button) dialogView.findViewById(R.id.btnDeleteCancel);

                final AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();

                btnDeleteConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        user.setStatus(ENABLE);
                        mUserDB.child(selectedItemID).setValue(user);
                        Toast.makeText(ManageUserActivity.this, "Kích hoạt người dùng thành công", Toast.LENGTH_SHORT).show();
                        alertDialog.dismiss();
                    }
                });

                btnDeleteCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }

            return true;
        }

        if(item.getTitle().equals(contextMenuEdit)){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int index = info.position;
            final User user = data.get(index);
            final String selectedItemID = user.getuID();
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
            LayoutInflater inflater = getLayoutInflater();
            final View dialogView = inflater.inflate(R.layout.change_user_info_dialog, null);
            dialogBuilder.setView(dialogView);
            final Button btnUpdateUserConfirm = (Button) dialogView.findViewById(R.id.btnUpdateUserConfirm);
            final Button btnUpdateUserCancel = (Button) dialogView.findViewById(R.id.btnUpdateUserCancel);
            Button btnChooseImg = dialogView.findViewById(R.id.btnNewImgUpload);
            final EditText edtNewEmpName = dialogView.findViewById(R.id.edtNewEmpName);

            imgNewImgUpload = dialogView.findViewById(R.id.imgNewImgUpload);
            Picasso.get().load(user.getImgURL()).into(imgNewImgUpload);
            final Spinner spnNewRole = dialogView.findViewById(R.id.spnNewRole);
            edtNewEmpName.setText(user.getEmpName());
            btnChooseImg.setOnClickListener(onChooseImageClicked);
            if(user.getRole().equals(MANAGER)){
                spnNewRole.setSelection(0);
            }
            if(user.getRole().equals(EMPLOYEE)){
                spnNewRole.setSelection(1);
            }
            final AlertDialog alertDialog = dialogBuilder.create();
            alertDialog.show();


            btnUpdateUserConfirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(TextUtils.isEmpty(edtNewEmpName.getText())){
                        edtNewEmpName.setError("Vui lòng nhập tên người dùng mới");
                        edtNewEmpName.requestFocus();
                        return;
                    }
                    if(imgUri != null){//nếu không chọn hình và không có hình trên firebase
                        fileRef = storageReference.child(System.currentTimeMillis() + "." + getFileExtension(imgUri));
                    }
                    if(fileRef != null){
                        if(uploadTask != null && uploadTask.isInProgress()){
                            Toast.makeText(ManageUserActivity.this, "Đang cập nhật vui lòng chò!!!", Toast.LENGTH_SHORT).show();
                        }else{
                            uploadTask = fileRef.putFile(imgUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                    FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                                    if(user.getImgURL() != null){
                                        firebaseStorage.getReferenceFromUrl(user.getImgURL()).delete();
                                    }
                                    Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                                    while(!uriTask.isComplete());
                                    Uri downloadUrl = uriTask.getResult();
                                    String updatedURL = downloadUrl.toString();
                                    user.setImgURL(updatedURL);
                                    user.setEmpName(edtNewEmpName.getText().toString());
                                    user.setRole(spnNewRole.getSelectedItem().toString());
                                    mUserDB.child(selectedItemID).setValue(user);
                                    Toast.makeText(ManageUserActivity.this, UPDATESUCCESS, Toast.LENGTH_SHORT).show();
                                    flag = true;
                                    alertDialog.dismiss();
                                }
                            });
                        }
                    }
                    if(!flag){
                        user.setEmpName(edtNewEmpName.getText().toString());
                        user.setRole(spnNewRole.getSelectedItem().toString());
                        mUserDB.child(selectedItemID).setValue(user);
                        Toast.makeText(ManageUserActivity.this, UPDATESUCCESS, Toast.LENGTH_SHORT).show();
                        flag = false;
                        alertDialog.dismiss();
                    }
                }
            });

            btnUpdateUserCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });
            return true;
        }

        if(item.getTitle().equals(contextMenuReset)){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int index = info.position;
            final User user = data.get(index);
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
            LayoutInflater inflater = getLayoutInflater();
            final View dialogView = inflater.inflate(R.layout.password_confirm_dialog, null);
            dialogBuilder.setView(dialogView);
            final Button btnConfirmPassword = (Button) dialogView.findViewById(R.id.btnConfirmPassword);
            final Button btnCancelPassword = (Button) dialogView.findViewById(R.id.btnCancelPassword);
            final EditText edtPasswordToConfirm = (EditText) dialogView.findViewById(R.id.edtPasswordToConfirm);
            final AlertDialog alertDialog = dialogBuilder.create();
            alertDialog.show();

            btnConfirmPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String password = edtPasswordToConfirm.getText().toString();
                    if(password.isEmpty()){
                        edtPasswordToConfirm.setError("Vui lòng nhập mật khẩu");
                        edtPasswordToConfirm.requestFocus();
                        return;
                    }else{
                        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                        AuthCredential credential = EmailAuthProvider
                                .getCredential(currentUser.getEmail(), password);
                        currentUser.reauthenticate(credential)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        FirebaseAuth.getInstance().sendPasswordResetEmail(user.getEmail())
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            alertDialog.dismiss();
                                                            Toast.makeText(ManageUserActivity.this, EMAILSENT, Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(ManageUserActivity.this, INCORRECTPASSWORD, Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        });
                    }
                }
            });

            btnCancelPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });
        }
        return false;
    }



    private View.OnClickListener onChooseImageClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent, IMAGE_REQUEST);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){
            imgUri = data.getData();

            Picasso.get().load(imgUri).into(imgNewImgUpload);
        }
    }

    private String getFileExtension(Uri uri){
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private boolean checkCurrentUser(String uID){
        boolean flag = false;
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if(user.getUid().equals(uID)){
            flag = true;
        }
        return flag;
    }
}