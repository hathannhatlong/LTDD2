package tdc.edu.vn.quanlyquanan;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;
import tdc.edu.vn.quanlyquanan.adapters.MyRecyclerViewAdapterBanAn;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class MainEmployeeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    //TODO: Views from layout
    ViewFlipper viewFlipper;
    Animation in, out;
    RecyclerView recyclerViewBanAn;
    TextView tvMaBan;
    public static TextView tvEmpName;
    public static TextView tvEmail;
    public static CircleImageView imgURLEmp;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle drawerToggle;
    //TODO: Adapter and data source
    private ArrayList<Integer> listImgViewFlipper;
    private ArrayList<DinnerTable> listBanBan;
    private ArrayList<FoodnDrink> listMonAn;
    public static MyRecyclerViewAdapterBanAn adapter;
    //TODO: Intent
    private Intent intent;
    //TODO: Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference mData;
    //TODO: Prototies
    long backPressedTime;
    Calendar calendar;
    String empName = "";
    String email;
    public static String imgURL = "";
    private int soBan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_nav_with_layout);
        //Get View from layout
        AnhXa();
        tvMaBan = findViewById(R.id.btnMaBan);

        //Create and Get Intent to processing data bundle
        intent = new Intent(MainEmployeeActivity.this, EmployeeMenuActivity.class);
        intent = getIntent();
        Bundle dataBundle = intent.getBundleExtra("dataEmp");
        empName = dataBundle.getString("empName");
        email = dataBundle.getString("email");
        imgURL = dataBundle.getString("imgURL");

        //Navigation View
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.openDrawer, R.string.closeDrawer);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        //Calendar
        calendar = Calendar.getInstance();
        //Firebase
        mData = FirebaseDatabase.getInstance().getReference();
        //View Flipper Sile
        slideViewFlipper();

        //Data RecyclerView BanAn
        listBanBan = new ArrayList<DinnerTable>();
        recyclerViewBanAn();

        //get Navigation view header
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View viewHeader = navigationView.getHeaderView(0);
        tvEmail = viewHeader.findViewById(R.id.tvEmailEmp);
        tvEmpName = viewHeader.findViewById(R.id.tvEmpName);
        imgURLEmp = viewHeader.findViewById(R.id.imgEmp);
        imgURLEmp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent.setClass(MainEmployeeActivity.this, FullPhotoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });
        Picasso.get().load(imgURL).into(imgURLEmp);
        tvEmail.setText(email);
        tvEmpName.setText(empName);

    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()){
            logout();
        }else {
            Toast.makeText(this, "Quay lại một lần nữa để thoát chương trình", Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }

    @Override
    protected void onResume() {

        listBanBan.clear();
        mData.child("DinnerTable").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                DinnerTable dinnerTable = dataSnapshot.getValue(DinnerTable.class);
                listBanBan.add(new DinnerTable(dinnerTable.getId(), dinnerTable.getNumberTable(), dinnerTable.getListFoodnDrink(), dinnerTable.getDate()));
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        adapter.notifyDataSetChanged();

        super.onResume();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        DrawerLayout drawerLayout = findViewById(R.id.nav_drawer);
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            drawerLayout.openDrawer(GravityCompat.START);
        }

        return super.onOptionsItemSelected(item);
    }


    private void AnhXa() {
        recyclerViewBanAn = findViewById(R.id.recyclerViewBanAn);
        viewFlipper = findViewById(R.id.viewFlipper);
        drawerLayout = findViewById(R.id.nav_drawer);
    }

    private void slideViewFlipper() {
        listImgViewFlipper = new ArrayList<Integer>();
        listImgViewFlipper.add(R.drawable.v1);
        listImgViewFlipper.add(R.drawable.v2);
        listImgViewFlipper.add(R.drawable.v3);
        listImgViewFlipper.add(R.drawable.v4);
        for (int i = 0; i < listImgViewFlipper.size(); i++) {
            ImageView imageView = new ImageView(this);
            imageView.setImageBitmap(loadLagreImage(listImgViewFlipper.get(i),200,200));
            viewFlipper.addView(imageView);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }

        viewFlipper.setFlipInterval(3000);
        viewFlipper.setAutoStart(true);
        in = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        out = AnimationUtils.loadAnimation(this, R.anim.fade_out);
        viewFlipper.setInAnimation(in);
        viewFlipper.setOutAnimation(out);
    }


    private void recyclerViewBanAn() {
        final GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerViewBanAn.setLayoutManager(layoutManager);
        adapter = new MyRecyclerViewAdapterBanAn(R.layout.cardview_layout_main_employee, listBanBan);
        adapter.setmClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(v.getContext());
                dialog.setContentView(R.layout.create_table_layout);
                final TextView tv_lapBan = dialog.findViewById(R.id.tv_lapBan);
                TextView tv_xemThucDon = dialog.findViewById(R.id.tv_xemThucDon);
                tv_lapBan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!listBanBan.get(soBan - 1).getDate().isEmpty()){
                            Toast.makeText(MainEmployeeActivity.this,"Bàn đang sử dụng",Toast.LENGTH_SHORT).show();
                        }else {
                            Intent intent = new Intent(v.getContext(), EmployeeMenuActivity.class);
                            Bundle data = new Bundle();
                            data.putString("soBan", listBanBan.get(soBan - 1).getNumberTable() + "");
                            intent.putExtra("maBan", data);
                            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(intent);
                            updateTable(listBanBan.get(soBan - 1));

                            dialog.cancel();
                            dialog.dismiss();
                        }

                    }
                });

                soBan = Integer.parseInt(listBanBan.get(recyclerViewBanAn.getChildLayoutPosition(v)).getNumberTable() + "");
                tv_xemThucDon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!listBanBan.get(soBan - 1).getDate().isEmpty()){
                            Intent intent = new Intent(v.getContext(), ThucDonActivity.class);
                            Bundle data = new Bundle();
                            data.putString("soBan", listBanBan.get(soBan - 1).getNumberTable() + "");
                            intent.putExtra("maBan", data);
                            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                            startActivity(intent);
                            dialog.cancel();
                            dialog.dismiss();
                        }else {
                            Toast.makeText(MainEmployeeActivity.this, "Bàn Đang Trống Nên Không Xem Được Thực Đơn", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

                dialog.show();
            }
        });

        recyclerViewBanAn.setAdapter(adapter);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        switch (id) {
            case R.id.ic_changePass:
                changePass();
                break;
            case R.id.ic_logout:
                logout();
                break;
            case R.id.ic_iforRestaurant:
                intent.setClass(MainEmployeeActivity.this, InforRestaurantActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                break;
            case R.id.ic_inforApp:
                intent.setClass(MainEmployeeActivity.this, InforAppActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                break;
            case R.id.ic_perInfor:
                intent.setClass(MainEmployeeActivity.this, PersonalyInforActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                break;
            default:
                break;
        }
        return false;
    }



    public void updateTable(DinnerTable dinnerTable) {
        final DinnerTable table = dinnerTable;
        // String date = calendar.get(Calendar.DATE) + "/" + (calendar.get(Calendar.MONTH)+1) + "/" + calendar.get(Calendar.YEAR);
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        Date c = Calendar.getInstance().getTime();
        String formattedDate = df.format(c);
        DinnerTable editTable = new DinnerTable();
        editTable.setId(table.getId());
        editTable.setDate(formattedDate);
        editTable.setListFoodnDrink(table.getListFoodnDrink());
        editTable.setNumberTable(table.getNumberTable());

        mData.child("DinnerTable").child(table.getId()).setValue(editTable);
    }

    private void changePass() {
        intent.setClass(MainEmployeeActivity.this, ChangePassActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }

    public Bitmap loadLagreImage(int imageID, int targetHeight, int targetWidth){
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(getResources(),imageID,options);
        final int originalHeight = options.outHeight;
        final int originalWidth = options.outWidth;
        int inSampleSize = 1;
        while (originalHeight / (inSampleSize*2) > targetHeight && (originalWidth / (inSampleSize*2) > targetWidth)){
            inSampleSize *= 2;
        }
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(getResources(),imageID,options);
    }

    private void logout(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Bạn có chắc chắn muốn đăng xuất không?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        intent.setClass(MainEmployeeActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
    }
}
