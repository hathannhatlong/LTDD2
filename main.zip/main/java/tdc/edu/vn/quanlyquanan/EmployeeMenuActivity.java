package tdc.edu.vn.quanlyquanan;

import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import tdc.edu.vn.quanlyquanan.adapters.MyRecyclerViewAdapterMenuMonAn;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class EmployeeMenuActivity extends AppCompatActivity {
    private RecyclerView recyclerViewMenu;
    private ArrayList<DinnerTable> listDinnerTable;
    private ArrayList<FoodnDrink> data;
    private MyRecyclerViewAdapterMenuMonAn adapter;
    private Intent intent;
    private int soBan;
    private int positionMenu;
    //FireBase
    DatabaseReference mFoodnDrinkDatabase;
    DatabaseReference mData;
    FirebaseStorage mStorage;
    StorageReference mImageStorage;
    ValueEventListener mDBListener;
    String FOODNDRINK = "FoodnDrink";
    String UPLOADS = "uploads";

    String amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_employee_menu_layout);
        AnhXa();
        mData = FirebaseDatabase.getInstance().getReference();
        intent = getIntent();
        final Bundle dataBundle = intent.getBundleExtra("maBan");
        soBan = Integer.parseInt(dataBundle.getString("soBan"));



        //dasdas
        final Dialog dialog = new Dialog(EmployeeMenuActivity.this);
        data = new ArrayList<FoodnDrink>();
        listDinnerTable = new ArrayList<DinnerTable>();

        mData.child("DinnerTable").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                DinnerTable dinnerTable = dataSnapshot.getValue(DinnerTable.class);
                listDinnerTable.add(new DinnerTable(dinnerTable.getId(),dinnerTable.getNumberTable(),dinnerTable.getListFoodnDrink(),dinnerTable.getDate()));
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerViewMenu.setLayoutManager(layoutManager);
        adapter = new MyRecyclerViewAdapterMenuMonAn(R.layout.cardview_menu_employee_layout,data);
        adapter.setmClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.setContentView(R.layout.dialog_amount_fooddrink_layout);
                positionMenu = recyclerViewMenu.getChildLayoutPosition(v);
                final EditText edtSoLuong = dialog.findViewById(R.id.edt_soLuong);

                final Button btnOK = dialog.findViewById(R.id.btnOK);
                btnOK.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        amount = edtSoLuong.getText().toString();
                        if(checkDataAmount()==true){
                            boolean isFood = false;
                            int position = 0;
                            final DinnerTable table = listDinnerTable.get(soBan-1);
                            DinnerTable editTable = new DinnerTable();
                            ArrayList<FoodnDrink> foodnDrinks = new ArrayList<>();
                            foodnDrinks = table.getListFoodnDrink();

                            for (int i = 0; i < foodnDrinks.size(); i++){
                                if(foodnDrinks.get(i).getName().equals(data.get(positionMenu).getName())){
                                    position = i;
                                    isFood = true;
                                }
                            }

                            if(isFood == true){
                                foodnDrinks.get(position).setAmount((foodnDrinks.get(position).getAmount() + Integer.parseInt(edtSoLuong.getText().toString())));
                                editTable.setId(table.getId());
                                editTable.setDate(table.getDate());
                                editTable.setListFoodnDrink(foodnDrinks);
                                editTable.setNumberTable(table.getNumberTable());
                                mData.child("DinnerTable").child(table.getId()).setValue(editTable);
                            }else {
                                foodnDrinks.add(new FoodnDrink(mFoodnDrinkDatabase.push().getKey(),data.get(positionMenu).getName()
                                        ,data.get(positionMenu).getPrice(),Integer.parseInt(edtSoLuong.getText().toString()),data.get(positionMenu).getImgURL()));
                                editTable.setId(table.getId());
                                editTable.setDate(table.getDate());
                                editTable.setListFoodnDrink(foodnDrinks);
                                editTable.setNumberTable(table.getNumberTable());
                                mData.child("DinnerTable").child(table.getId()).setValue(editTable);
                            }

                            MainEmployeeActivity.adapter.notifyDataSetChanged();
                            dialog.cancel();
                            dialog.dismiss();
                        }
                    }
                });
                dialog.show();
            }
        });
        recyclerViewMenu.setAdapter(adapter);
        //Firebase
        mFoodnDrinkDatabase = FirebaseDatabase.getInstance().getReference(FOODNDRINK);
        mStorage = FirebaseStorage.getInstance();
        mImageStorage = FirebaseStorage.getInstance().getReference(UPLOADS);
        mDBListener = mFoodnDrinkDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data.clear();//Clear arraylist to avoid duplication
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    FoodnDrink tmpItem = ds.getValue(FoodnDrink.class);
                    data.add(tmpItem);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_item_search_view,menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);

        SearchView searchView = (SearchView) searchItem.getActionView();

        searchView.setQueryHint(getString(R.string.hintSearch));
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                List<FoodnDrink> foodnDrinks = new ArrayList<>();
                for(FoodnDrink foodnDrink : data){
                    if(foodnDrink.getName().toLowerCase().contains(newText.toLowerCase())){
                        foodnDrinks.add(foodnDrink);
                    }
                }
                adapter.searchItem(foodnDrinks);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mFoodnDrinkDatabase.removeEventListener(mDBListener);
    }
    private void AnhXa(){
        recyclerViewMenu = findViewById(R.id.recyclerView_menu);
    }


    private boolean checkDataAmount(){
        if(amount.isEmpty()){
            Toast.makeText(this, "Vui lòng nhập số lượng", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(Integer.parseInt(amount) <= 0){
            Toast.makeText(this, "Vui lòng nhập số lượng lớn 0", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }


}
