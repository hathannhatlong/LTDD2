package tdc.edu.vn.quanlyquanan;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import tdc.edu.vn.quanlyquanan.data_models.User;

public class SignupActivity extends AppCompatActivity {

    EditText edtEmail, edtPassword, edtEmpName;
    Spinner spnRole;
    Button btnSignUp, btnChooseAnImg;
    Uri imgUri;
    ImageView imgUploads;
    String USERSIMG = "users"; // Node contains employees picture in Firebase Storage
    String USERS = "Users";// Node contains employees info in Realtime Database
    String imgStorageURL;
    static final int IMAGE_REQUEST = 1;

    StorageReference mImageStorage;
    DatabaseReference mRef;
    StorageTask uploadTask;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_layout);
        mAuth = FirebaseAuth.getInstance();
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtEmpName = (EditText) findViewById(R.id.edtEmpName);
        spnRole = (Spinner) findViewById(R.id.spnRole);
        imgUploads = (ImageView) findViewById(R.id.imgEmpPicture);
        btnChooseAnImg = (Button) findViewById(R.id.btnUploadEmpImg);

        btnSignUp = (Button) findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(onSignUpClicked);

        btnChooseAnImg.setOnClickListener(onChooseImageClicked);


        mRef = FirebaseDatabase.getInstance().getReference(USERS);
        mImageStorage = FirebaseStorage.getInstance().getReference(USERSIMG);
    }

    private View.OnClickListener onSignUpClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final String email = edtEmail.getText().toString().trim();
            final String password = edtPassword.getText().toString().trim();
            final String empName = edtEmpName.getText().toString().trim();
            final String role = spnRole.getSelectedItem().toString().trim();
            final StorageReference fileRef;

            if(uploadTask != null && uploadTask.isInProgress()){
                Toast.makeText(SignupActivity.this, "Đang thêm người dùng vui lòng chờ!!!", Toast.LENGTH_SHORT).show();
            }else {
                if(email.isEmpty()){
                    edtEmail.setError("Vui lòng nhập email");
                    edtEmail.requestFocus();
                    return;
                }
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    edtEmail.setError("Vui lòng nhập đúng cú pháp email");
                    edtEmail.requestFocus();
                    return;
                }
                if(password.isEmpty()){
                    edtPassword.setError("Vui lòng nhập mật khẩu");
                    edtPassword.requestFocus();
                    return;
                }
                if(password.length() < 6){
                    edtPassword.setError("Mật khẩu phải nhiều hơn 6 kí tự");
                    edtPassword.requestFocus();
                    return;
                }
                if(empName.isEmpty()){
                    edtEmpName.setError("Vui lòng nhập tên người dùng");
                    edtEmpName.requestFocus();
                    return;
                }
                if(empName.length() < 2){
                    edtEmpName.setError("Tên người dùng phải nhiều hơn 2 kí tự");
                    edtEmpName.requestFocus();
                    return;
                }
                if(imgUri == null){
                    Toast.makeText(SignupActivity.this,"Vui lòng chọn ảnh người dùng",Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    fileRef = mImageStorage.child(System.currentTimeMillis() + "." + getFileExtension(imgUri));
                }
                uploadTask = fileRef.putFile(imgUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                        while(!uriTask.isComplete());
                        Uri downloadUrl = uriTask.getResult();
                        imgStorageURL = downloadUrl.toString();
                        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                //progressBar.setVisibility(View.GONE);
                                if (task.isSuccessful()) {
                                    String uID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                    User user = new User(email, empName, role, uID,imgStorageURL);
                                    FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).
                                            setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Toast.makeText(SignupActivity.this, "Thêm người dùng thành công", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                } else {
                                    if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                        Toast.makeText(getApplicationContext(), "Email đăng kí đã được sử dụng", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        });
                    }
                });
            }
        }
    };


    private View.OnClickListener onChooseImageClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent, IMAGE_REQUEST);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){
            imgUri = data.getData();

            Picasso.get().load(imgUri).into(imgUploads);
        }
    }

    private String getFileExtension(Uri uri){
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }
}