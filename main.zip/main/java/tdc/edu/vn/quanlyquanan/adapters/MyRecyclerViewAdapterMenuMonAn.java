package tdc.edu.vn.quanlyquanan.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import tdc.edu.vn.quanlyquanan.R;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class MyRecyclerViewAdapterMenuMonAn extends RecyclerView.Adapter<MyRecyclerViewAdapterMenuMonAn.MyViewHolder> {
    private int layoutID;
    private ArrayList<FoodnDrink> data;
    private View.OnClickListener mClickListener;

    public void setmClickListener(View.OnClickListener mClickListener) {
        this.mClickListener = mClickListener;
    }

    public MyRecyclerViewAdapterMenuMonAn(int layoutID, ArrayList<FoodnDrink> data) {
        this.layoutID = layoutID;
        this.data = data;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView tv_tenMon;
        private TextView tv_gia;
        private ImageView imgItemMenu;
        public MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            tv_tenMon = itemView.findViewById(R.id.tv_tenMon);
            tv_gia = itemView.findViewById(R.id.tv_gia);
            imgItemMenu = (ImageView) itemView.findViewById(R.id.imgItemMenu);
        }
    }

    @NonNull
    @Override
    public MyRecyclerViewAdapterMenuMonAn.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        CardView listViewItem = (CardView) inflater.inflate(layoutID,viewGroup,false);
        listViewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mClickListener.onClick(v);
            }
        });
        return new MyViewHolder(listViewItem);
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewAdapterMenuMonAn.MyViewHolder viewHolder, int i) {
        viewHolder.tv_tenMon.setText(data.get(i).getName());
        viewHolder.tv_gia.setText(data.get(i).getPrice()+" VND");
        Picasso.get().load(data.get(i).getImgURL()).fit().centerCrop().into(viewHolder.imgItemMenu);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void searchItem(List<FoodnDrink> foodnDrinks){
        data = new ArrayList<>();
        data.addAll(foodnDrinks);
        notifyDataSetChanged();
    }
}
