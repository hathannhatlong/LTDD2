package tdc.edu.vn.quanlyquanan.adapters;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


import java.util.ArrayList;

import tdc.edu.vn.quanlyquanan.R;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;

public class MyRecyclerViewAdapterBanAn extends RecyclerView.Adapter<MyRecyclerViewAdapterBanAn.MyViewHolder> {
    private int layoutID;
    private ArrayList<DinnerTable> data;
    private View.OnClickListener mClickListener;

    public void setmClickListener(View.OnClickListener mClickListener) {
        this.mClickListener = mClickListener;
    }

    public MyRecyclerViewAdapterBanAn(int layoutID, ArrayList<DinnerTable> data) {
        this.layoutID = layoutID;
        this.data = data;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView btnMaBan;
        private TextView tv_TenBan;

        public MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            btnMaBan = itemView.findViewById(R.id.btnMaBan);
            tv_TenBan = itemView.findViewById(R.id.tv_TenBan);

        }
    }

    @NonNull
    @Override
    public MyRecyclerViewAdapterBanAn.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        CardView listViewItem = (CardView) inflater.inflate(layoutID,viewGroup,false);
        listViewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mClickListener.onClick(v);
            }
        });
        return new MyViewHolder(listViewItem);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyRecyclerViewAdapterBanAn.MyViewHolder viewHolder, int i) {
        viewHolder.btnMaBan.setText(data.get(i).getNumberTable()+"");
        viewHolder.tv_TenBan.setText("Ban So " + data.get(i).getNumberTable());
        if (!data.get(i).getDate().equals("")){
            viewHolder.btnMaBan.setBackgroundDrawable(viewHolder.btnMaBan.getResources().getDrawable(R.drawable.tv_dinner_table_created));
        }else {
            viewHolder.btnMaBan.setBackgroundDrawable(viewHolder.btnMaBan.getResources().getDrawable(R.drawable.button_ban_an));
        }

    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
