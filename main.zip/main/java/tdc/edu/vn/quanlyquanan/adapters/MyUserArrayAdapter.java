package tdc.edu.vn.quanlyquanan.adapters;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import tdc.edu.vn.quanlyquanan.R;
import tdc.edu.vn.quanlyquanan.data_models.User;

public class MyUserArrayAdapter extends ArrayAdapter {
    private Activity context;
    private int layoutID;
    private ArrayList<User> listUser;

    public MyUserArrayAdapter(Activity context, int resource,ArrayList<User> objects) {
        super(context, resource, objects);
        this.context = context;
        layoutID = resource;
        listUser = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = context.getLayoutInflater().inflate(layoutID, parent, false);
            viewHolder.userName = (TextView) convertView.findViewById(R.id.lvUserName);
            viewHolder.userEmail = (TextView) convertView.findViewById(R.id.lvUserEmail);
            viewHolder.userImg = (CircleImageView) convertView.findViewById(R.id.lvUserImg);
            viewHolder.userRole = (TextView) convertView.findViewById(R.id.lvUserRole);
            viewHolder.userStatus = (TextView) convertView.findViewById(R.id.lvUserStatus);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        final User user = listUser.get(position);
        viewHolder.userName.setText(user.getEmpName());
        viewHolder.userEmail.setText(user.getEmail());
        Picasso.get().load(user.getImgURL()).into(viewHolder.userImg); // Image
        viewHolder.userRole.setText(user.getRole());
        viewHolder.userStatus.setText(user.getStatus());
        return convertView;
    }

    public class ViewHolder{
        TextView userName;
        TextView userEmail;
        CircleImageView userImg;
        TextView userRole;
        TextView userStatus;
    }
}
