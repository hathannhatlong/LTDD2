package tdc.edu.vn.quanlyquanan.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import tdc.edu.vn.quanlyquanan.R;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class MyArrayAdapterBillPayment extends ArrayAdapter<FoodnDrink> {
    private Activity context;
    private int layoutID;
    private ArrayList<FoodnDrink> listMonAn;


    public MyArrayAdapterBillPayment(Activity context, int resource, ArrayList<FoodnDrink> objects) {
        super(context, resource, objects);
        this.context = context;
        this.layoutID = resource;
        this.listMonAn = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_bill_layout, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tv_nameFood_bill = convertView.findViewById(R.id.tv_nameFood_bill);
            viewHolder.tv_amountFood_bill = convertView.findViewById(R.id.tv_amountFood_bill);
            viewHolder.tv_PriceFood_bill = convertView.findViewById(R.id.tv_PriceFood_bill);
            viewHolder.img_bill = convertView.findViewById(R.id.img_bill);
            viewHolder.tv_total_ThucDon = convertView.findViewById(R.id.tv_total_ThucDon);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (MyArrayAdapterBillPayment.ViewHolder) convertView.getTag();
        }

        final FoodnDrink foodnDrink = listMonAn.get(position);
        viewHolder.tv_total_ThucDon.setText(foodnDrink.total().toString() + "đ");
        viewHolder.tv_PriceFood_bill.setText(foodnDrink.getPrice()+" đ");
        viewHolder.tv_amountFood_bill.setText(foodnDrink.getAmount()+"");
        viewHolder.tv_nameFood_bill.setText(foodnDrink.getName());
        Picasso.get().load(foodnDrink.getImgURL()).fit().centerCrop().into(viewHolder.img_bill);
        return convertView;
    }

    public class ViewHolder{
        TextView tv_nameFood_bill;
        TextView tv_PriceFood_bill;
        TextView tv_amountFood_bill;
        TextView tv_total_ThucDon;
        ImageView img_bill;
    }
}
