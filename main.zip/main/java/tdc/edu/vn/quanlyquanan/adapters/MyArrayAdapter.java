package tdc.edu.vn.quanlyquanan.adapters;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import tdc.edu.vn.quanlyquanan.R;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;

public class MyArrayAdapter extends ArrayAdapter<DinnerTable> {
    private Activity context;
    private int layoutID;
    private ArrayList<DinnerTable> listTable;


    public MyArrayAdapter(Activity context, int resource,ArrayList<DinnerTable> objects) {
        super(context, resource, objects);
        this.context = context;
        layoutID = resource;
        listTable = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = context.getLayoutInflater().inflate(layoutID, parent, false);
            viewHolder.tableNumber = (TextView) convertView.findViewById(R.id.tvTableNumber);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        final DinnerTable table = listTable.get(position);
        Log.d("table", table.toString());
        viewHolder.tableNumber.setText("Bàn " + table.getNumberTable());
        return convertView;
    }

    public class ViewHolder{
        TextView tableNumber;
    }
}
