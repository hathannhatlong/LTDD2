package tdc.edu.vn.quanlyquanan.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import tdc.edu.vn.quanlyquanan.R;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class ThucDonAdapter extends ArrayAdapter<FoodnDrink> {

    private Activity context;
    private int layoutID;
    private ArrayList<FoodnDrink> listMonAn;


    public ThucDonAdapter(Activity context, int resource, ArrayList<FoodnDrink> objects) {
        super(context, resource, objects);
        this.context = context;
        this.layoutID = resource;
        this.listMonAn = objects;
    }

    @Override
    public View getView(final int position,View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_thuc_don_layout, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tv_tenMon_ThucDon = convertView.findViewById(R.id.tv_tenMon_ThucDon);
            viewHolder.tv_soLuong_ThucDon = convertView.findViewById(R.id.tv_soLuong_ThucDon);
            viewHolder.tv_giaMon = convertView.findViewById(R.id.tv_giaMon);
            viewHolder.img_hinhMon = convertView.findViewById(R.id.img_hinhMonThucDon);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        final FoodnDrink foodnDrink = listMonAn.get(position);
        viewHolder.tv_tenMon_ThucDon.setText(foodnDrink.getName());
        viewHolder.tv_soLuong_ThucDon.setText(foodnDrink.getAmount()+"");
        viewHolder.tv_giaMon.setText(foodnDrink.getPrice()+" đ");
        Picasso.get().load(foodnDrink.getImgURL()).fit().centerCrop().into(viewHolder.img_hinhMon);
        return convertView;
    }

    public class ViewHolder {
        TextView tv_tenMon_ThucDon;
        TextView tv_soLuong_ThucDon;
        TextView tv_giaMon;
        CircleImageView img_hinhMon;
    }
}
