package tdc.edu.vn.quanlyquanan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class FullPhotoActivity extends AppCompatActivity {
    ImageView imgFull;
    Intent intent;
    String imgURL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_photo_layout);
        imgFull = findViewById(R.id.imgFull);
        //Create and Get Intent to processing data bundle
        intent = new Intent(FullPhotoActivity.this, EmployeeMenuActivity.class);
        intent = getIntent();
        Bundle dataBundle = intent.getBundleExtra("dataEmp");
        imgURL = dataBundle.getString("imgURL");
        Picasso.get().load(imgURL).into(imgFull);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Picasso.get().load(MainEmployeeActivity.imgURL).into(imgFull);
    }
}
