package tdc.edu.vn.quanlyquanan;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.SimpleTimeZone;

import tdc.edu.vn.quanlyquanan.adapters.MyRecyclerViewAdapterBanAn;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;
import tdc.edu.vn.quanlyquanan.data_models.Order;

public class CustomerOrderTableChoiseActivity extends AppCompatActivity {

    RecyclerView recyclerViewBanAn;
    private ArrayList<DinnerTable> listBanBan;
    public static MyRecyclerViewAdapterBanAn adapter;
    private int soBan;
    TextView tvMaBan;
    private Intent intent;
    String empName = "";
    String email;
    String imgURL = "";
    String Customerid="";
    //Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference mData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_order_table_choise_layout);
        AnhXa();

        tvMaBan = findViewById(R.id.btnMaBan);
        //Firebase
        mData = FirebaseDatabase.getInstance().getReference();
        //View Flipper Sile
        //slideViewFlipper();
        //Data RecyclerView BanAn
        listBanBan = new ArrayList<DinnerTable>();
        intent = getIntent();
        Bundle dataBundle = intent.getBundleExtra("dataEmp");
        empName = dataBundle.getString("empName");
        email = dataBundle.getString("email");
        imgURL = dataBundle.getString("imgURL");
        Customerid = dataBundle.getString("uID");

        recyclerViewBanAn();
    }

    @Override
    protected void onResume() {
        listBanBan.clear();
        mData.child("DinnerTable").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                DinnerTable dinnerTable = dataSnapshot.getValue(DinnerTable.class);
                listBanBan.add(new DinnerTable(dinnerTable.getId(), dinnerTable.getNumberTable(), dinnerTable.getListFoodnDrink(), dinnerTable.getDate()));
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        adapter.notifyDataSetChanged();

        super.onResume();
    }


    private void AnhXa() {
        recyclerViewBanAn = findViewById(R.id.recyclerViewBanAnOrder);
    }


    private void recyclerViewBanAn() {
        final GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerViewBanAn.setLayoutManager(layoutManager);
        adapter = new MyRecyclerViewAdapterBanAn(R.layout.cardview_layout_main_employee, listBanBan);
        adapter.setmClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog = new Dialog(v.getContext());
                dialog.setContentView(R.layout.book_table_layout);
                final TextView tv_yes = dialog.findViewById(R.id.tv_Booking_yes);
                TextView tv_no = dialog.findViewById(R.id.tv_Booking_no);
                tv_yes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(!listBanBan.get(soBan - 1).getDate().isEmpty()){
                            Toast.makeText(CustomerOrderTableChoiseActivity.this,"Bàn đang sử dụng",Toast.LENGTH_SHORT).show();
                        }else {
                            Intent intent = new Intent(CustomerOrderTableChoiseActivity.this, CustomerOrderActivity.class);
                            Bundle data = new Bundle();
                            data.putString("soBan", listBanBan.get(soBan - 1).getNumberTable() + "");
                            data.putString("empName",empName);
                            data.putString("email",email);
                            data.putString("uID",Customerid);
                            intent.putExtra("dataEmp",data);
                            startActivity(intent);
                            dialog.cancel();
                            dialog.dismiss();
                        }

                    }
                });

                soBan = Integer.parseInt(listBanBan.get(recyclerViewBanAn.getChildLayoutPosition(v)).getNumberTable() + "");
                tv_no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                        dialog.dismiss();
                    }
                });


                dialog.show();

//                Toast.makeText(v.getContext(), listBanBan.get(recyclerViewBanAn.getChildLayoutPosition(v)).getNumberTable() + "", Toast.LENGTH_SHORT).show();
            }
        });
        recyclerViewBanAn.setAdapter(adapter);
    }
}
