package tdc.edu.vn.quanlyquanan;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class InforRestaurantActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.restaurant_infor_layout);

    }

}
