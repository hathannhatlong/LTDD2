package tdc.edu.vn.quanlyquanan;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import tdc.edu.vn.quanlyquanan.adapters.MyArrayAdapter;
import tdc.edu.vn.quanlyquanan.data_models.DinnerTable;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class ViewTableListActivity extends AppCompatActivity {


    private ArrayList<DinnerTable> data;
    private Button btnAddTable;
    private ListView listView_Table;
    private MyArrayAdapter adapter;
    private String confirmMessage = "Bạn muốn xóa bàn?";
    private String updateMessage = "Sửa số bàn thành công!!!";
    private String contextMenuDelete = "Xóa";
    private String contextMenuEdit = "Sửa";
    EditText edtNumber;
    String TABLE = "DinnerTable";
    DatabaseReference mTableDB;
    ValueEventListener mDBListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_table_list_layout);

        listView_Table = (ListView) findViewById(R.id.listView_Table);

        btnAddTable = (Button) findViewById(R.id.btnAddTable);
        edtNumber = (EditText) findViewById(R.id.tableNumber);

        data = new ArrayList<>();

        adapter = new MyArrayAdapter(this,R.layout.list_view_item_layout,data);

        listView_Table.setAdapter(adapter);

        mTableDB = FirebaseDatabase.getInstance().getReference(TABLE);

        mDBListener = mTableDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data.clear();
                DinnerTable tmp = new DinnerTable();
                for(DataSnapshot ds : dataSnapshot.getChildren()){
                    tmp = ds.getValue(DinnerTable.class);
                    data.add(tmp);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        btnAddTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnAddTable.setClickable(false);
                String id = mTableDB.push().getKey();
                String tableNumber = edtNumber.getText().toString();
                ArrayList<FoodnDrink> listFood = new ArrayList<>();
                listFood.add(new FoodnDrink(id,"Rau Song",0.0,0,"https://znews-photo.zadn.vn/w660/Uploaded/sgorvz/2016_06_17/rau_song.jpg"));
                if(tableNumber.isEmpty()){
                    edtNumber.setError("Vui lòng nhập số bàn!!!");
                    edtNumber.requestFocus();
                    return;
                }
                for(DinnerTable table : data){
                    if(table.getNumberTable() == Integer.parseInt(edtNumber.getText().toString())){
                        edtNumber.setError("Số bàn này đã có vui lòng nhập số khác!!!");
                        edtNumber.requestFocus();
                        edtNumber.setText("");
                        return;
                    }
                }
                DinnerTable tmp = new DinnerTable();
                tmp.setId(id);
                tmp.setNumberTable(Integer.parseInt(tableNumber));
                tmp.setDate("");
                tmp.setListFoodnDrink(listFood);
                mTableDB.child(id).setValue(tmp).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(ViewTableListActivity.this, "Thêm bàn thành công", Toast.LENGTH_SHORT).show();
                        edtNumber.setText("");
                        btnAddTable.setClickable(true);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ViewTableListActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        btnAddTable.setClickable(true);
                    }
                });
            }
        });

        registerForContextMenu(listView_Table);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Chọn chức năng");
        menu.add(Menu.NONE,1,1,contextMenuDelete);
        menu.add(Menu.NONE,2,2,contextMenuEdit);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if(item.getTitle().equals(contextMenuDelete)){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int index = info.position;
            final DinnerTable table = data.get(index);
            final String selectedItemID = table.getId();

            if(!table.getDate().isEmpty()){
                Toast.makeText(this, "Bàn đang được sử dụng không thể xóa", Toast.LENGTH_SHORT).show();
            }else{
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.delete_confirm_dialog, null);
                TextView message = dialogView.findViewById(R.id.confirm_dialog_message);
                message.setText(confirmMessage);
                dialogBuilder.setView(dialogView);
                final Button btnDeleteConfirm = (Button) dialogView.findViewById(R.id.btnDeleteConfirm);
                final Button btnDeleteCancel = (Button) dialogView.findViewById(R.id.btnDeleteCancel);

                final AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();

                btnDeleteConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mTableDB.child(selectedItemID).removeValue();
                        Toast.makeText(ViewTableListActivity.this, "Xóa bàn thành công", Toast.LENGTH_SHORT).show();
                        alertDialog.dismiss();
                    }
                });

                btnDeleteCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }

            return true;
        }
        if(item.getTitle().equals(contextMenuEdit)){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            int index = info.position;
            final DinnerTable table = data.get(index);
            final String selectedItemID = table.getId();

            if(!table.getDate().isEmpty()){
                Toast.makeText(this, "Bàn đang được sử dụng không thể sửa", Toast.LENGTH_SHORT).show();
            }else{
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.update_table_dialog, null);

                dialogBuilder.setView(dialogView);
                final Button btnUpdateConfirm = (Button) dialogView.findViewById(R.id.btnUpdateTable);
                final Button btnUpdateCancel = (Button) dialogView.findViewById(R.id.btnCancelUpdateTable);
                final EditText edtNumberUpdate = (EditText) dialogView.findViewById(R.id.tableNumberUpdate);
                final AlertDialog alertDialog = dialogBuilder.create();
                alertDialog.show();

                btnUpdateConfirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(TextUtils.isEmpty(edtNumberUpdate.getText())){
                            edtNumberUpdate.setError("Vui lòng nhập số bàn mới");
                            edtNumberUpdate.requestFocus();
                            return;
                        }
                        for(DinnerTable table : data){
                            if(table.getNumberTable() == Integer.parseInt(edtNumberUpdate.getText().toString())){
                                edtNumberUpdate.setError("Số bàn này đã có vui lòng nhập số khác!!!");
                                edtNumberUpdate.requestFocus();
                                edtNumberUpdate.setText("");
                                return;
                            }
                        }
                        table.setNumberTable(Integer.parseInt(edtNumberUpdate.getText().toString()));
                        mTableDB.child(selectedItemID).setValue(table);
                        Toast.makeText(ViewTableListActivity.this, updateMessage, Toast.LENGTH_SHORT).show();
                        alertDialog.dismiss();
                    }
                });

                btnUpdateCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                    }
                });
            }
        }
        return false;
    }
}