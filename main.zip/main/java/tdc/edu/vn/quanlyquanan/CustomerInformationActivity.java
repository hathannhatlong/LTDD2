package tdc.edu.vn.quanlyquanan;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import tdc.edu.vn.quanlyquanan.data_models.Customer;
import tdc.edu.vn.quanlyquanan.data_models.User;

public class CustomerInformationActivity extends AppCompatActivity {

    //Todo: Prototies
//  ImageView imgPer;
    CircleImageView imgPer;
    EditText edtEditRole, edtEditEmail,edtEditName;
    Button btnEditPer, btnEdited, btnChooseImage, btnCancelEdit;
    //TODO: Firebase
    private FirebaseAuth mAuth;
    DatabaseReference mData;
    FirebaseUser user;

    Uri imgUri;
    StorageTask updateTask;
    StorageReference mImageStorage;
    String USERS = "Users";
    String CUSTOMER = "Customers";
    FirebaseStorage mStorage;
    //TODO: Intent
    private ProgressDialog dialog;
    private Intent intent;
    Bundle dataBundle;
    static final int IMAGE_REQUEST = 1;
    String ENABLE = "ENABLE";
    String empName;
    String role;
    String uID;
    String imgURL;
    public static String url;
    String phone = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_information_layout);
        //Get View from Layout
        getView();
        dialog = new ProgressDialog(this);
        //Firebase
        mData = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        mStorage = FirebaseStorage.getInstance();
        mImageStorage = FirebaseStorage.getInstance().getReference(USERS);
        FirebaseStorage mStorage;

//        //Intent
        intent = new Intent(CustomerInformationActivity.this, HomepagerActivity.class);
        intent = getIntent();
        dataBundle = intent.getBundleExtra("dataEmp");

        empName = dataBundle.getString("empName");
        role = dataBundle.getString("role");
        imgURL = dataBundle.getString("imgURL");
        uID = dataBundle.getString("uID");
        edtEditName.setText(empName);
        edtEditRole.setText(role);
        phone = "0123456789";
        //hide some functions when running the first Activity
        hideView();
        edtEditEmail.setEnabled(false);
        edtEditRole.setEnabled(false);

        //Processing
        edtEditEmail.setText(user.getEmail());
        Picasso.get().load(imgURL).into(imgPer);

        btnChooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, IMAGE_REQUEST);
            }
        });

        btnEditPer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showView();
                btnEditPer.setVisibility(View.INVISIBLE);
            }
        });

        btnEdited.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!(imgUri == null) || !(edtEditName.getText().equals(empName))){
                    User edituser = new User(user.getEmail() ,empName,role,uID,imgURL);
                    editPersoaly(edituser);
                    hideView();
                    btnEdited.setVisibility(View.INVISIBLE);
                }
                else {
                    Toast.makeText(CustomerInformationActivity.this, "Bạn chưa đổi thông tin nào cả!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancelEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnEditPer.setVisibility(View.VISIBLE);
                hideView();
            }
        });
    }


    //Get View
    private void getView(){
        imgPer = findViewById(R.id.img_editCustomer);
        edtEditEmail = findViewById(R.id.edtEditEmailCustomer);
        edtEditName = findViewById(R.id.edtEditNameCustomer);
        edtEditRole = findViewById(R.id.edtEditRole);
        btnEditPer = findViewById(R.id.btnEditCustomer);
        btnEdited = findViewById(R.id.btnEditedCustomer);
        btnChooseImage = findViewById(R.id.btnChooseImageCustomer);
        btnCancelEdit = findViewById(R.id.btnCancelEditCustomer);
    }

    private void hideView(){
        btnChooseImage.setVisibility(View.INVISIBLE);
        btnEdited.setVisibility(View.INVISIBLE);
        edtEditName.setEnabled(false);
        btnCancelEdit.setVisibility(View.INVISIBLE);
    }

    private void showView(){
        btnChooseImage.setVisibility(View.VISIBLE);
        btnEdited.setVisibility(View.VISIBLE);
        edtEditName.setEnabled(true);
        btnCancelEdit.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){
            imgUri = data.getData();
            Picasso.get().load(imgUri).into(imgPer);
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }


    //TODO: Function update infor user
    private void editPersoaly(final User user){
        final User itemUser = user;

        final StorageReference fileRef;
        final String updatedName = edtEditName.getText().toString();
        final String updatedEmail = edtEditEmail.getText().toString();
        final String updatedRole = edtEditRole.getText().toString();

        if(updatedName.isEmpty()){
            edtEditName.setError("New item name is required");
            return;
        }
        dialog.setMessage("Đang đổi thông tin người dùng");
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        if(imgUri == null){
            Toast.makeText(CustomerInformationActivity.this, "Food picture is required", Toast.LENGTH_SHORT).show();
            return;
        }else{
            fileRef = mImageStorage.child(System.currentTimeMillis() + "." + getFileExtension(imgUri));
        }
//        fileRef = mImageStorage.child(getFileExtension(imgUri));
        if(updateTask != null && updateTask.isInProgress()){
            Toast.makeText(CustomerInformationActivity.this, "Update is in progress!!!", Toast.LENGTH_SHORT).show();
        }else{
            updateTask = fileRef.putFile(imgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    //Delay progress bar reset for visual confirmation
                    dialog.dismiss();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dialog.dismiss();
                    Toast.makeText(CustomerInformationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
//                    if(!itemUser.getImgURL().isEmpty()){
//                        mStorage.getReferenceFromUrl(itemUser.getImgURL()).delete();
//                    }
                    Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                    while(!uriTask.isComplete());
                    Uri downloadUrl = uriTask.getResult();
                    String updatedURL = "";
                    if(imgUri == null){
                        updatedURL = imgURL;

                    }else {
                        updatedURL = downloadUrl.toString();
                    }

                    User editedUser = new User();
                    editedUser.setuID(itemUser.getuID());
                    editedUser.setEmail(itemUser.getEmail());
                    editedUser.setRole(itemUser.getRole());
                    editedUser.setImgURL(updatedURL);
                    editedUser.setEmpName(updatedName);
                    editedUser.setStatus(ENABLE);

                    mData.child("Users").child(itemUser.getuID()).setValue(editedUser);

                    Customer editCustomer = new Customer();
                    editCustomer.setuID(itemUser.getuID());
                    editCustomer.setCusEmail(itemUser.getEmail());
                    editCustomer.setCusRole(itemUser.getRole());
                    editCustomer.setCusPhone(phone);
                    editCustomer.setImgURL(updatedURL);
                    editCustomer.setCusName(updatedName);
                    mData.child(CUSTOMER).child(itemUser.getuID()).setValue(editCustomer);

                    dialog.dismiss();
                    btnEditPer.setVisibility(View.VISIBLE);
                    Toast.makeText(CustomerInformationActivity.this, "Item updated", Toast.LENGTH_SHORT).show();

                    intent.setClass(CustomerInformationActivity.this,HomepagerActivity.class);
                    dataBundle.putString("imgURL",updatedURL);
                    dataBundle.putString("empName",updatedName);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.putExtra("dataEmp", dataBundle);
                    startActivity(intent);

                }
            });
        }
    }

    public Bitmap loadLagreImage(int imageID, int targetHeight, int targetWidth){
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(getResources(),imageID,options);
        final int originalHeight = options.outHeight;
        final int originalWidth = options.outWidth;
        int inSampleSize = 1;
        while (originalHeight / (inSampleSize*2) > targetHeight && (originalWidth / (inSampleSize*2) > targetWidth)){
            inSampleSize *= 2;
        }
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(getResources(),imageID,options);
    }

    @Override
    protected void onResume() {
        super.onResume();

    }
}
