package tdc.edu.vn.quanlyquanan;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Vector;

import tdc.edu.vn.quanlyquanan.adapters.MyRecycleViewAdapter;
import tdc.edu.vn.quanlyquanan.data_models.FoodnDrink;

public class ViewMenuActivity extends AppCompatActivity implements MyRecycleViewAdapter.OnItemClickListener {
    StorageReference fileRef;
    RecyclerView recyclerView;
    DatabaseReference mFoodnDrinkDatabase;
    FirebaseStorage mStorage;
    StorageReference mImageStorage;
    ValueEventListener mDBListener;
    String FOODNDRINK = "FoodnDrink";
    String UPLOADS = "uploads";
    ArrayList<FoodnDrink> data;
    MyRecycleViewAdapter adapter;

    StorageTask updateTask;
    boolean flag = false;
    static final int IMAGE_REQUEST = 1;
    Uri imgUri;
    ImageView imgUploadsUpdate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_menu_layout);
        recyclerView = (RecyclerView) findViewById(R.id.recycleView_Menu);
        data = new ArrayList<>();
        Button addNewItem = findViewById(R.id.btnAddNewMenuItem);

        addNewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewMenuActivity.this, AddMenuItemActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        adapter = new MyRecycleViewAdapter(R.layout.my_card_view_layout, data);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(ViewMenuActivity.this);
        mFoodnDrinkDatabase = FirebaseDatabase.getInstance().getReference(FOODNDRINK);
        mStorage = FirebaseStorage.getInstance();
        mImageStorage = FirebaseStorage.getInstance().getReference(UPLOADS);
        mDBListener = mFoodnDrinkDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data.clear();//Clear arraylist to avoid duplication
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    FoodnDrink tmpItem = ds.getValue(FoodnDrink.class);
                    data.add(tmpItem);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private View.OnClickListener onDeleteClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mFoodnDrinkDatabase.removeEventListener(mDBListener);
    }

    @Override
    public void OnItemClick(int position) {
        //TODO none
    }

    @Override
    public void onEditClick(int position) {
        FoodnDrink itemToEdit = data.get(position);
        showUpdateDialog(itemToEdit);
    }

    @Override
    public void onDeleteClick(int position) {
        final FoodnDrink selectedItem = data.get(position);
        final String selectedItemID = selectedItem.getId();

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.delete_confirm_dialog, null);
        dialogBuilder.setView(dialogView);
        final Button btnDeleteConfirm = (Button) dialogView.findViewById(R.id.btnDeleteConfirm);
        final Button btnDeleteCancel = (Button) dialogView.findViewById(R.id.btnDeleteCancel);

        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

        btnDeleteConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StorageReference imgRef = mStorage.getReferenceFromUrl(selectedItem.getImgURL());
                imgRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        mFoodnDrinkDatabase.child(selectedItemID).removeValue();
                        Toast.makeText(ViewMenuActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();

                        alertDialog.dismiss();
                    }
                });
            }
        });

        btnDeleteCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    private void showUpdateDialog(FoodnDrink item) {
        final FoodnDrink itemEdit = item;
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.update_menu_item_dialog, null);
        dialogBuilder.setView(dialogView);
        final EditText edtUpdateName = (EditText) dialogView.findViewById(R.id.edtItemNameUpdateDialog);
        final EditText edtUpdatePrice = (EditText) dialogView.findViewById(R.id.edtItemPriceUpdateDialog);
        imgUploadsUpdate = (ImageView) dialogView.findViewById(R.id.imgUploadUpdateDialog);
        final Button btnChooseImgUpdate = (Button) dialogView.findViewById(R.id.btnUploadsUpdateDialog);
        final Button btnUpdate = (Button) dialogView.findViewById(R.id.btnAddMenuItemUpdateDialog);
        final Button btnCancel = (Button) dialogView.findViewById(R.id.btnCancelUpdateDialog);
        final ProgressBar progressBarUpdate = (ProgressBar) dialogView.findViewById(R.id.addItemProgessBarUpdateDialog);
        edtUpdateName.setText(itemEdit.getName());
        edtUpdatePrice.setText(itemEdit.getPrice().toString());
        Picasso.get().load(itemEdit.getImgURL()).into(imgUploadsUpdate);

        dialogBuilder.setTitle("Cập nhập thông tin");
        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

        btnChooseImgUpdate.setOnClickListener(onChooseImageClicked);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fileRef = null;
                final String updatedName = edtUpdateName.getText().toString();
                final Double updatedPrice = Double.parseDouble(edtUpdatePrice.getText().toString());
                if(TextUtils.isEmpty(edtUpdateName.getText())){
                    edtUpdateName.setError("Vui lòng nhập tên món");
                    edtUpdateName.requestFocus();
                    return;
                }
                if(TextUtils.isEmpty(edtUpdatePrice.getText())){
                    edtUpdatePrice.setError("Vui lòng nhập giá món");
                    edtUpdatePrice.requestFocus();
                    return;
                }
                if(imgUri != null){
                    fileRef = mImageStorage.child(System.currentTimeMillis() + "." + getFileExtension(imgUri));
                }
                if(fileRef != null){
                    if(updateTask != null && updateTask.isInProgress()){
                        Toast.makeText(ViewMenuActivity.this, "Đang cập nhật vui lòng chờ!!!", Toast.LENGTH_SHORT).show();
                    }else{
                        updateTask = fileRef.putFile(imgUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                //Delay progress bar reset for visual confirmation
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBarUpdate.setProgress(0);
                                    }
                                }, 500);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(ViewMenuActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                                progressBarUpdate.setProgress((int) progress);
                            }
                        }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                if(!itemEdit.getImgURL().isEmpty()){
                                    mStorage.getReferenceFromUrl(itemEdit.getImgURL()).delete();
                                }
                                Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                                while(!uriTask.isComplete());
                                Uri downloadUrl = uriTask.getResult();
                                String updatedURL = downloadUrl.toString();
                                FoodnDrink editedItem = new FoodnDrink();
                                editedItem.setId(itemEdit.getId());
                                editedItem.setName(updatedName);
                                editedItem.setPrice(updatedPrice);
                                editedItem.setImgURL(updatedURL);
                                mFoodnDrinkDatabase.child(itemEdit.getId()).setValue(editedItem);

                                Toast.makeText(ViewMenuActivity.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                                flag = true;
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        alertDialog.dismiss();
                                    }
                                }, 1000);
                            }
                        });
                    }
                }
                if(!flag){
                    btnUpdate.setEnabled(false);
                    itemEdit.setName(updatedName);
                    itemEdit.setPrice(updatedPrice);
                    mFoodnDrinkDatabase.child(itemEdit.getId()).setValue(itemEdit);
                    Toast.makeText(ViewMenuActivity.this, "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                    flag = false;
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            alertDialog.dismiss();
                        }
                    }, 1000);
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private View.OnClickListener onChooseImageClicked = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent, IMAGE_REQUEST);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null){
            imgUri = data.getData();
            Picasso.get().load(imgUri).into(imgUploadsUpdate);
        }
    }
}