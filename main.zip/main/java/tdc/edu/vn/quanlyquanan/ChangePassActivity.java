package tdc.edu.vn.quanlyquanan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePassActivity extends AppCompatActivity {

    TextInputLayout edtOldPass,edtNewPass, edtNewPassAgain;
    TextView tvEmail;
    Button btnChangePass;
    private FirebaseAuth mAuth;
    private ProgressDialog dialog;
    private Intent intent;
    FirebaseUser user;
    String pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_pass_layout);
        getView();
        intent = new Intent(ChangePassActivity.this,MainEmployeeActivity.class);
        intent = getIntent();
        Bundle dataBundle = intent.getBundleExtra("dataEmp");
        pass = dataBundle.getString("password");
        dialog = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();

        tvEmail.setText(user.getEmail());

        btnChangePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkData()){

                    if(edtOldPass.getEditText().getText().toString().equals(pass)){
                        if(edtNewPassAgain.getEditText().getText().toString().equals(edtNewPass.getEditText().getText().toString())){
                            changePass(edtNewPassAgain.getEditText().getText().toString());
                        }else {
//                            Toast.makeText(ChangePassActivity.this, "Nhập Sai Nhập Lại Mật Khẩu Mới", Toast.LENGTH_SHORT).show();
                            edtNewPassAgain.setError("Nhập Sai Nhập Lại Mật Khẩu Mới");
                        }
                    }else {
//                        Toast.makeText(ChangePassActivity.this, "Nhập Sai Mật Khẩu Cũ", Toast.LENGTH_SHORT).show();
                        edtOldPass.setError("Nhập Sai Mật Khẩu Cũ");
                    }
                }
            }
        });
    }

    private void getView(){
        edtOldPass = findViewById(R.id.edtOldPass);
        edtNewPass = findViewById(R.id.edtNewPass);
        edtNewPassAgain = findViewById(R.id.edtNewPassAgain);
        tvEmail = findViewById(R.id.tvEmail);
        btnChangePass = findViewById(R.id.btnChange);
    }

    private void changePass(String newPass){
        if(user!=null){
            dialog.setMessage("Đang đổi mật khẩu");
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
            user.updatePassword(newPass).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        dialog.dismiss();
                        clearData();
                        Toast.makeText(ChangePassActivity.this,"Mật khẩu của bạn đã được đổi",Toast.LENGTH_SHORT).show();
                    }else {
                        dialog.dismiss();
                        Toast.makeText(ChangePassActivity.this,"Mật khẩu của bạn chưa được đổi",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }


    private boolean checkData(){
        if (edtOldPass.getEditText().getText().toString().isEmpty() && edtNewPass.getEditText().getText().toString().isEmpty() && edtNewPassAgain.getEditText().getText().toString().isEmpty()) {
            Toast.makeText(this, "Bạn chưa nhập dữ liệu", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (edtOldPass.getEditText().getText().toString().isEmpty()) {
//            Toast.makeText(this, "Bạn chưa nhập mật khẩu cữ", Toast.LENGTH_SHORT).show();
            edtOldPass.setError("Bạn chưa nhập mật khẩu cữ");
            return false;
        }
        if (edtNewPass.getEditText().getText().toString().isEmpty()) {
//            Toast.makeText(this, "Bạn chưa nhập mật khẩu mới", Toast.LENGTH_SHORT).show();
            edtNewPass.setError("Bạn chưa nhập mật khẩu mới");
            return false;
        }
        if (edtNewPassAgain.getEditText().getText().toString().isEmpty()) {
//            Toast.makeText(this, "Bạn chưa nhập lại mật khẩu mới", Toast.LENGTH_SHORT).show();
            edtNewPassAgain.setError("Bạn chưa nhập lại mật khẩu mới");
            return false;
        }
        return  true;
    }

    private void clearData(){
        edtOldPass.getEditText().setText("");
        edtNewPass.getEditText().setText("");
        edtNewPassAgain.getEditText().setText("");
        edtOldPass.requestFocus();
    }
}
