package com.example.callphone;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class NumberPhoneManage {
    DBHelper dbhelper;
    SQLiteDatabase db;

    public NumberPhoneManage(Context context) {
        dbhelper = new DBHelper(context);
    }
    public ArrayList<NumberPhone> LayDL(){
        ArrayList<NumberPhone> data = new ArrayList<>();
        String sql = "select * from qlnb order by ID desc";
        db = dbhelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        if((cursor.getCount() > 0) && cursor != null){
            do
            {
                NumberPhone phone = new NumberPhone();
                phone.setNumber(cursor.getString(1));
                data.add(phone);
            }
            while (cursor.moveToNext());
        }
        return data;
    }

    public int Themsp(NumberPhone phone){
        db = dbhelper.getWritableDatabase();
        //kiem tra san pham có tồn tại chưa
        String sql = "select * from qlnb where phone = '" + phone.getNumber()+"'";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        if(cursor.getCount() == 0){
            ContentValues values = new ContentValues();
            values.put("phone", phone.getNumber());

            db.insert("qlnb", null, values);
        }
        return cursor.getCount();
    }

    public int DelProduct(String val){
        db = dbhelper.getWritableDatabase();
        int resuilt = db.delete("qlnb", "phone =?",new String[]{val});
        return resuilt;
    }

}
