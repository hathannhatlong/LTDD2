package com.example.callphone;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CALL = 1;
    EditText txtNumberPhone;
    ImageView Phone_Call;
    ListView lvPhone;
    ArrayList<NumberPhone> list_danhsach = new ArrayList<>();
    CustomPhone arrAdapter_phone;
    NumberPhoneManage numberPhoneManage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setControl();
        setEvent();

    }

    private void setControl() {
        lvPhone = findViewById(R.id.listcall);
        txtNumberPhone = findViewById(R.id.txtnumber_phone);
        Phone_Call = findViewById(R.id.phone_call);
    }

    private void setEvent() {
        Loadds();
        Phone_Call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }

        });
        lvPhone.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                NumberPhone numberPhone = list_danhsach.get(position);
                final NumberPhoneManage numberPhoneManage = new NumberPhoneManage(getApplicationContext());
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Thông Báo!");
                builder.setMessage("Bạn có muốn xóa " +numberPhone.getNumber()+" ?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    NumberPhone numberPhone = list_danhsach.get(position);
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        numberPhoneManage.DelProduct(numberPhone.getNumber());
                        Loadds();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                return false;
            }
        });
    }

    private void Loadds() {
        numberPhoneManage = new NumberPhoneManage(getApplicationContext());
        list_danhsach = numberPhoneManage.LayDL();
        arrAdapter_phone = new CustomPhone(this, R.layout.custom_numberphone, list_danhsach);
        lvPhone.setAdapter(arrAdapter_phone);
    }

    private void addPhone(){
        numberPhoneManage = new NumberPhoneManage(getApplicationContext());
        NumberPhone numberPhone = new NumberPhone();
        numberPhone.setNumber(txtNumberPhone.getText().toString());
        numberPhoneManage.Themsp(numberPhone);
        Loadds();
    }


    private void makePhoneCall() {
        String number = txtNumberPhone.getText().toString();
        if(number.trim().length() > 0){
            addPhone();
            txtNumberPhone.setText("");
            if (ContextCompat.checkSelfPermission(MainActivity.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){

                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL );

            }else{
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }
        }else{
            NumberPhone numberPhone = list_danhsach.get(0);
            txtNumberPhone.setText(numberPhone.getNumber());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CALL){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){

                makePhoneCall();
            }else Toast.makeText(this, "Permission DENTED", Toast.LENGTH_LONG).show();
        }
    }
}
