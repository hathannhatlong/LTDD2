package com.example.callphone;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomPhone extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<NumberPhone> data;
    public CustomPhone(Context context, int resource, ArrayList<NumberPhone> data) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(resource,null);

        TextView textView = view.findViewById(R.id.cus_phonenumber);

        NumberPhone numberPhone = data.get(position);
        textView.setText(numberPhone.getNumber());
        return view;
    }
}
