package com.example.animation;

import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //ProgressBar
    ProgressBar progressBar;
    TextView percent;
    //Hooks
    View first, second, third, fourth, fifth, sixth;
    Button btnstart;
    ImageView img_cat;
    //animation
    Animation bottomanimation, first_anima, second_anima, third_anima, fourth_anima, fifth_anima, sixth_anima, btnAnimation, btnAnimation_click, img_animation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        first_anima = AnimationUtils.loadAnimation(this, R.anim.first_animation);
        second_anima = AnimationUtils.loadAnimation(this, R.anim.second_anima);
        third_anima = AnimationUtils.loadAnimation(this, R.anim.third_anima);
        fourth_anima = AnimationUtils.loadAnimation(this, R.anim.fouth_anima);
        fifth_anima = AnimationUtils.loadAnimation(this, R.anim.fifth_anima);
        sixth_anima = AnimationUtils.loadAnimation(this, R.anim.sixth_anima);
        bottomanimation = AnimationUtils.loadAnimation(this,R.anim.bottom_animaton);
        btnAnimation = AnimationUtils.loadAnimation(this, R.anim.buttom_anima);
        btnAnimation.setStartOffset(3000);
        btnAnimation_click = AnimationUtils.loadAnimation(this,R.anim.btn_to_click);
        setinterval_animation setinterval = new setinterval_animation(0.2,20);
        btnAnimation_click.setInterpolator(setinterval);
        img_animation = AnimationUtils.loadAnimation(this,R.anim.img_animation);
        setControl();
        setAnima();
        setEvent();
        //img
        AnimationDrawable runningcat = (AnimationDrawable)img_cat.getDrawable();
        runningcat.start();

        setProgressAnimation();
    }

    private void setProgressAnimation() {
        progressbaranimation progress = new progressbaranimation(this, progressBar, percent, 0, 100f);
        progress.setDuration(2900);
        progressBar.setAnimation(progress);
    }

    private void setEvent() {
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnstart.setAnimation(btnAnimation_click);
                btnstart.startAnimation(btnAnimation_click);
            }
        });
    }

    private void setAnima() {
        first.setAnimation(first_anima);
        second.setAnimation(second_anima);
        third.setAnimation(third_anima);
        fourth.setAnimation(fourth_anima);
        fifth.setAnimation(fifth_anima);
        sixth.setAnimation(sixth_anima);
        btnstart.setAnimation(btnAnimation);
        img_cat.setAnimation(img_animation);
        percent.setAnimation(img_animation);
    }

    private void setControl() {
        first = findViewById(R.id.first_line);
        second = findViewById(R.id.second_line);
        third = findViewById(R.id.third_line);
        fourth = findViewById(R.id.fourth_line);
        fifth = findViewById(R.id.fifth_line);
        sixth = findViewById(R.id.sixth_line);
        btnstart = findViewById(R.id.btn_go);
        img_cat = findViewById(R.id.img_cat);

        //progress
        progressBar = findViewById(R.id.progress_id);
        percent = findViewById(R.id.percent);
        progressBar.setMax(100);
        progressBar.setScaleY(3f);
    }

}
