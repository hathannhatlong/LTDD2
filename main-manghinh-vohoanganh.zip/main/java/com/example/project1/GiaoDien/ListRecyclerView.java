package com.example.project1.GiaoDien;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.GridView;
import android.widget.LinearLayout;

import com.example.project1.Adapter.CustomProduct;
import com.example.project1.Adapter.MyRecyclerView;
import com.example.project1.DataBase.ProductManagement;
import com.example.project1.Model.SanPham;
import com.example.project1.R;

import java.util.ArrayList;

public class ListRecyclerView extends AppCompatActivity {
    RecyclerView rvItem;
    ArrayList<SanPham> data_sanpham = new ArrayList<>();
    ProductManagement productManagement;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_recycler_view);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.titleRecy));
        getData();
        setControl();
        LinearLayoutManager layoutManager= new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        rvItem.setLayoutManager(layoutManager);
        rvItem.setHasFixedSize(true);
        rvItem.setAdapter(new MyRecyclerView(this, data_sanpham));
    }

    private void getData() {
        productManagement = new ProductManagement(getApplicationContext());
        data_sanpham = productManagement.LayDL();
    }

    private void setControl() {
        rvItem = findViewById(R.id.rv_item);
    }
}
