package com.example.project1.GiaoDien;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;

import com.example.project1.Adapter.CustomProduct;
import com.example.project1.DataBase.ProductManagement;
import com.example.project1.R;
import com.example.project1.Model.SanPham;

import java.util.ArrayList;

public class ListProduct extends AppCompatActivity {
    SearchView searchProduct;
    Button btnbBackHome, btnAddProducts, btnShowGrid, btnshowRecy;
    ListView lvProduct;
    ArrayList<SanPham> data_sanpham = new ArrayList<>();
    ArrayList<SanPham> data_search = new ArrayList<>();
    CustomProduct arrayAdapter_product;
    ProductManagement productManagement;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_product);
//      changes title for page
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.qlsanpham));
        setControl();
        setEvent();
    }

    private void setEvent() {
        LoadDs();
        btnAddProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListProduct.this , AddProduct.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        btnbBackHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListProduct.this , MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // xóa activity hiện tại
                startActivity(intent);
            }
        });

        lvProduct.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SanPham sanPham = data_sanpham.get(position);
                String sp = sanPham.getMaVatTu() +"/"+ sanPham.getTenVatTu()+"/"+ sanPham.getGia() +"/"+ sanPham.getDVT();
                Intent intent = new Intent(ListProduct.this, AddProduct.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Bundle bundle = new Bundle();
                bundle.putString("inforProduct", sp);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        searchProduct.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(newText.equals("")){
                    LoadDs();
                }else{
                    SearchItem(newText);
                }
                return true;
            }
        });

        btnShowGrid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListProduct.this, showlistgrid.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        btnshowRecy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListProduct.this, ListRecyclerView.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

    }

    //tìm kiem
    private void SearchItem(String text) {
        data_search.clear();
        for (SanPham sanPham: data_sanpham){
            if(sanPham.getMaVatTu().toLowerCase().contains(text)){
                data_search.add(sanPham);
            }
        }
        arrayAdapter_product = new CustomProduct(this, R.layout.custom_product, data_search);
        lvProduct.setAdapter(arrayAdapter_product);
    }

    private void LoadDs() {
        productManagement = new ProductManagement(getApplicationContext());
        data_sanpham = productManagement.LayDL();
        arrayAdapter_product = new CustomProduct(this, R.layout.custom_product, data_sanpham);
        lvProduct.setAdapter(arrayAdapter_product);
    }

    private void setControl() {
        btnbBackHome = findViewById(R.id.backhome);
        btnAddProducts = findViewById(R.id.addproduct);
        lvProduct = findViewById(R.id.lvds);
        searchProduct = findViewById(R.id.searchsp);
        btnShowGrid = findViewById(R.id.nextlvgrid);
        btnshowRecy = findViewById(R.id.nextRecy);
    }
}
