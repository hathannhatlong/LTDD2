package com.example.project1.GiaoDien;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;

import com.example.project1.Adapter.CustomProduct;
import com.example.project1.DataBase.ProductManagement;
import com.example.project1.Model.SanPham;
import com.example.project1.R;

import java.util.ArrayList;

public class showlistgrid extends AppCompatActivity {
    GridView gridView;
    ArrayList<SanPham> data_sanpham = new ArrayList<>();
    CustomProduct arrayAdapter_product;
    ProductManagement productManagement;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showlistgrid);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.titelgrid));
        setControl();
        getData();
    }

    private void getData() {
        productManagement = new ProductManagement(getApplicationContext());
        data_sanpham = productManagement.LayDL();
        arrayAdapter_product = new CustomProduct(this, R.layout.custom_grid, data_sanpham);
        gridView.setAdapter(arrayAdapter_product);
    }

    private void setControl() {
        gridView = findViewById(R.id.listgrid);
    }
}
