package com.example.project1.GiaoDien;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.project1.DataBase.ProductManagement;
import com.example.project1.DataBase.UnitManager;
import com.example.project1.Model.DonViTinh;
import com.example.project1.Model.SanPham;
import com.example.project1.R;

import java.util.ArrayList;

public class AddProduct extends AppCompatActivity {
    EditText txtMaSp, txtTenSp, txtgiaSp;
    Button btnAddSp, btnDelSp, btnUpdateSp, btnClear, btnAddUnit;
    Spinner spDonViTinh;
    ArrayList <DonViTinh> data_dvt = new ArrayList<>();
    ArrayAdapter arrayAdapter_dvt;
    UnitManager unitManager;
    ProductManagement productManagement ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

//       changes title for page
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.themsanpham));
        setControl();
        setEvent();
    }

    private void setEvent() {
        CheckPosition();
        getDVT();
        btnAddSp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                productManagement = new ProductManagement(getApplicationContext());
                if(txtMaSp.getText().toString().equals("") || txtTenSp.getText().toString().equals("") || txtgiaSp.getText().toString().equals("") ){
                    Toast.makeText(getApplication(), "Không cho phép có trường rỗng!", Toast.LENGTH_LONG).show();
                    return;
                }
                try{
                    int check = Integer.parseInt(txtgiaSp.getText().toString());
                }catch (NumberFormatException ex){
                    Toast.makeText(getApplication(), "Trường giá không phải là số!", Toast.LENGTH_LONG).show();
                    txtgiaSp.requestFocus();
                    return;
                }
                SanPham sanPham = getSanPham();
                if(productManagement.Themsp(sanPham) == 0){
                    Toast.makeText(getApplication(),"Thêm sảm phẩm thành công!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddProduct.this , ListProduct.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }else Toast.makeText(getApplication(),"Sản phẩm đã tồn tại!", Toast.LENGTH_LONG).show();

            }
        });

        btnDelSp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(AddProduct.this);
                builder.setTitle("Thông báo");
                builder.setMessage("Bạn có chắc chắn muốn xóa sản phẩm "+txtTenSp.getText()+"?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        productManagement = new ProductManagement(getApplicationContext());
                        if(productManagement.DelProduct(txtMaSp.getText().toString()) > 0){
                            Toast.makeText(getApplication(),"Xóa thành công",Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(AddProduct.this,ListProduct.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        }else Toast.makeText(getApplication(),"Xóa không thành công!!!",Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

        btnUpdateSp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtMaSp.setText("");
                txtTenSp.setText("");
                txtgiaSp.setText("");
                spDonViTinh.setSelection(0);
                disableBtn(false);
                txtMaSp.requestFocus();
            }
        });

        btnAddUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddProduct.this, ListUnit.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

    }

    //kiem tra dau vao có sửa hay xóa (click selectitem từ listview)
    private void CheckPosition() {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if(bundle != null){
            disableBtn(true);

            String sanPham = bundle.getString("inforProduct");
            String[] sanphamslipt = sanPham.split("/");
            txtMaSp.setText(sanphamslipt[0]);
            txtTenSp.setText(sanphamslipt[1]);
            txtgiaSp.setText(sanphamslipt[2]);
            spDonViTinh.setSelection(data_dvt.indexOf(sanphamslipt[3]));
        }
    }

    private SanPham getSanPham() {
        SanPham sanPham = new SanPham();
        DonViTinh donViTinh = new DonViTinh();
        sanPham.setMaVatTu(txtMaSp.getText().toString());
        sanPham.setTenVatTu(txtTenSp.getText().toString());
        sanPham.setGia(Integer.parseInt(txtgiaSp.getText().toString()));
        donViTinh.setDvt(spDonViTinh.getSelectedItem().toString());
        sanPham.setDVT(donViTinh);
        return sanPham;
    }

    private void setControl() {
        txtMaSp = findViewById(R.id.masp);
        txtTenSp = findViewById(R.id.tensp);
        txtgiaSp = findViewById(R.id.giasanpham);
        spDonViTinh = findViewById(R.id.spDVT);

        btnAddSp = findViewById(R.id.addproduct);
        btnDelSp = findViewById(R.id.delproduct);
        btnUpdateSp = findViewById(R.id.updatesproduct);
        btnClear = findViewById(R.id.cleartext);
        btnAddUnit = findViewById(R.id.btnaddUnit);


        disableBtn(false);
    }


    private void getDVT() {
        unitManager = new UnitManager(getApplicationContext());
        if( unitManager.LayDVT() != null){
            data_dvt = unitManager.LayDVT();
            arrayAdapter_dvt = new ArrayAdapter(this, android.R.layout.simple_spinner_item, data_dvt);
            spDonViTinh.setAdapter(arrayAdapter_dvt);
        }

    }
    private void disableBtn(boolean check){
        btnUpdateSp.setEnabled(check);
        btnDelSp.setEnabled(check);
        btnAddSp.setEnabled(!check);
        txtMaSp.setEnabled(!check);
        if(check == true){
            btnUpdateSp.setBackgroundResource(R.drawable.border_btn);
            btnDelSp.setBackgroundResource(R.drawable.border_btn);
            btnUpdateSp.setTextColor(getResources().getColor(R.color.colorPrimary));
            btnDelSp.setTextColor(getResources().getColor(R.color.colorPrimary));
            btnAddSp.setBackgroundResource(R.drawable.disable_btn);
            btnAddSp.setTextColor(getResources().getColor(R.color.disble));
            txtMaSp.setTextColor(getResources().getColor(R.color.disble));
        }else{
            btnUpdateSp.setBackgroundResource(R.drawable.disable_btn);
            btnDelSp.setBackgroundResource(R.drawable.disable_btn);
            btnUpdateSp.setTextColor(getResources().getColor(R.color.disble));
            btnDelSp.setTextColor(getResources().getColor(R.color.disble));
            btnAddSp.setBackgroundResource(R.drawable.border_btn);
            btnAddSp.setTextColor(getResources().getColor(R.color.colorPrimary));
            txtMaSp.setTextColor(getResources().getColor(R.color.colorPrimary));
        }
    }
}
