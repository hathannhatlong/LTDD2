package com.example.project1.GiaoDien;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.project1.R;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Button btnsanpham, btnkho;
    Menu optionsMenu;
    String lag = "";
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //changes title app when language changes
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.app_name));

        // create settting for keyword when change language
        sharedPreferences = getSharedPreferences("Settings", MODE_PRIVATE);

        //get value from setting with keyword my_lang
        lag = sharedPreferences.getString("My_Lang","");


        setControl();
        setEvent();

    }

    private void setEvent() {
        btnsanpham.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListProduct.class);
                startActivity(intent);
            }
        });
    }

    private void setControl() {
        btnsanpham = findViewById(R.id.toproduct);
        btnkho = findViewById(R.id.tokho);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_bar, menu);
        //the first app loading, set value for key word Mylang = ""
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        editor.putString("My_Lang", "");
//        editor.commit();

        optionsMenu = menu;
        MenuItem items = optionsMenu.findItem(R.id.mnlanguage);
        if(lag.equals("") || lag.equals("en")){
            items.setIcon(R.drawable.uk);
        }else if(lag.equals("vi")) {
            items.setIcon(R.drawable.vetnam);
        }
//        Toast.makeText(getApplication(), lag, Toast.LENGTH_LONG).show();
        return super.onCreateOptionsMenu(menu);
    }

        @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.mnlanguage:
                if(lag.equals("vi")){
                    setLanguge("en");
                }else {
                    setLanguge("vi");
                }
                break;
            case R.id.exit:
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Thông báo");
                builder.setMessage("Bạn có muốn thoát?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    // changes language
    private void setLanguge(String lang) {
        Locale locale= new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("My_Lang", lang);
        editor.commit();

        //reload shen change language
        recreate();

    }

//    // Lấy lang từ shared
//    public void loadLocale(){
//        SharedPreferences pref = getSharedPreferences("Settings", Activity.MODE_PRIVATE);
//        String language = pref.getString("My_Lang", "");
//        setLanguge(language);
//    }
}
