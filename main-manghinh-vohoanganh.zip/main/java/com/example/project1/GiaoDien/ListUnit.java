package com.example.project1.GiaoDien;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.project1.Adapter.CustomUnit;
import com.example.project1.DataBase.UnitManager;
import com.example.project1.Model.DonViTinh;
import com.example.project1.R;

import java.util.ArrayList;

public class ListUnit extends AppCompatActivity{

    ListView lvUnit;
    EditText txtUnit;
    Button btnThemUnit, btnDelUnit, btncomeback;
    ArrayList<DonViTinh> data_Unit = new ArrayList<>();
    CustomUnit adapter_Unit;
    UnitManager unitManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_unit);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.page_unit));
        setControl();
        setEvent();
    }

    private void setEvent() {
        LoadListUnit();
        btnThemUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unitManager = new UnitManager(getApplicationContext());
                if(txtUnit.getText().toString().equals("")){
                    Toast.makeText(getApplication(), "Trường Unit không cho phép rỗng!", Toast.LENGTH_LONG).show();
                    return;
                }
                unitManager.ThemDVT(txtUnit.getText().toString());
                LoadListUnit();

            }
        });
        btncomeback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListUnit.this , AddProduct.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // xóa activity hiện tại
                startActivity(intent);
            }
        });

        lvUnit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(ListUnit.this, "aaa", Toast.LENGTH_LONG).show();
            }
        });
//
//        lvUnit.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
//            @Override
//            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(ListUnit.this, "aaa", Toast.LENGTH_LONG).show();
//                return false;
//            }
//        });
    }

    private void LoadListUnit() {
        unitManager = new UnitManager(getApplicationContext());
        data_Unit = unitManager.LayDVT();
        adapter_Unit = new CustomUnit(this, R.layout.custom_unit, data_Unit);
        lvUnit.setAdapter(adapter_Unit);
    }

    private void setControl() {
        lvUnit = findViewById(R.id.lvUnit);
        btnThemUnit = findViewById(R.id.add_unit);
        txtUnit = findViewById(R.id.txt_Unit);
        btnDelUnit = findViewById(R.id.btn_del_unit);
        btncomeback = findViewById(R.id.comeback_product);
    }
}
