package com.example.project1.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.example.project1.DataBase.DBHelper;
import com.example.project1.Model.DonViTinh;

import java.util.ArrayList;

import static android.widget.Toast.LENGTH_LONG;

public class UnitManager {
    DBHelper dbhelper;
    SQLiteDatabase db;

    public UnitManager(Context context) {
        dbhelper = new DBHelper(context);
    }

    public ArrayList<DonViTinh> LayDVT(){
        ArrayList<DonViTinh> data = new ArrayList<>();
        String sql = "select * from qlDVT order by ID desc";
        db = dbhelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();

        if((cursor.getCount() > 0) && cursor != null){
            do
            {
                DonViTinh donViTinh = new DonViTinh();
                donViTinh.setDvt(cursor.getString(1));
                data.add(donViTinh);
            }
            while (cursor.moveToNext());
        }

        return data;
    }

    public void ThemDVT(String val){
        db = dbhelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("DVT", val);
        db.insert("qlDVT", null, values);
    }

    public int  Del(String val){
        db = dbhelper.getWritableDatabase();
        String sql = "select * from qlVT where DVT = '" + val +"'";
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.getCount() == 0){
            db.delete("qlDVT", "DVT =?",new String[]{val});
        }
        return cursor.getCount();
    }

    public void DelAll(){
        db.delete("qlDVT",null,null);
    }
}
