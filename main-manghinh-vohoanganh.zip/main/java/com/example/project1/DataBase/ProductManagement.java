package com.example.project1.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.project1.Model.DonViTinh;
import com.example.project1.Model.SanPham;

import java.util.ArrayList;

public class ProductManagement {
    DBHelper dbhelper;
    SQLiteDatabase db;

    public ProductManagement(Context context) {
        dbhelper = new DBHelper(context);
    }
    public ArrayList<SanPham> LayDL(){
        ArrayList<SanPham> data = new ArrayList<>();
        String sql = "select * from qlVT order by ID desc";
        db = dbhelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        if((cursor.getCount() > 0) && cursor != null){
            do
            {
                SanPham sanPham = new SanPham();
                DonViTinh donViTinh = new DonViTinh();
                sanPham.setMaVatTu(cursor.getString(1));
                sanPham.setTenVatTu(cursor.getString(2));
                donViTinh.setDvt(cursor.getString(3));
                sanPham.setDVT(donViTinh);
                sanPham.setGia(Integer.parseInt(cursor.getString(4)));
                data.add(sanPham);
            }
            while (cursor.moveToNext());
        }

        return data;
    }

    public int Themsp(SanPham sanPham){
        db = dbhelper.getWritableDatabase();
        //kiem tra san pham có tồn tại chưa
        String sql = "select * from qlVT where MaVT = '" + sanPham.getMaVatTu()+"'";
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();
        if(cursor.getCount() == 0){
            ContentValues values = new ContentValues();
            values.put("MaVT", sanPham.getMaVatTu());
            values.put("TenVT", sanPham.getTenVatTu());
            values.put("DVT", sanPham.getDVT());
            values.put("Gia", sanPham.getGia());
            db.insert("qlVT", null, values);
        }
        return cursor.getCount();
    }

    public int DelProduct(String val){
        db = dbhelper.getWritableDatabase();
        int resuilt = db.delete("qlVT", "MaVT =?",new String[]{val});
        return resuilt;
    }
    public void DelAll(){
        db.delete("qlVT",null,null);
    }
}
