package com.example.project1.Model;

public class DonViTinh {
    String dvt;

    @Override
    public String toString() {
        return dvt ;
    }

    public String getDvt() {
        return dvt;
    }

    public void setDvt(String dvt) {
        this.dvt = dvt;
    }
}
