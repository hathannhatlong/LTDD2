package com.example.project1.Model;

public class SanPham {
    String MaVatTu, TenVatTu;
    Integer Gia;
    DonViTinh DVT;

    public Integer getGia() {
        return Gia;
    }

    public void setGia(Integer gia) {
        Gia = gia;
    }

    public String getDVT() {
        return DVT.getDvt();
    }

    public void setDVT(DonViTinh DVT) {
        this.DVT = DVT;
    }

    @Override
    public String toString() {
        return "SanPham{" +
                "MaVatTu='" + MaVatTu + '\'' +
                ", TenVatTu='" + TenVatTu + '\'' +
                ", DVT='" + DVT.toString() + '\'' +
                ", Gia='" + Gia + '\'' +
                '}';
    }

    public String getMaVatTu() {
        return MaVatTu;
    }

    public void setMaVatTu(String maVatTu) {
        MaVatTu = maVatTu;
    }

    public String getTenVatTu() {
        return TenVatTu;
    }

    public void setTenVatTu(String tenVatTu) {
        TenVatTu = tenVatTu;
    }


}
