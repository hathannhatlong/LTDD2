package com.example.project1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project1.R;
import com.example.project1.Model.SanPham;

import java.util.ArrayList;

public class CustomProduct extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<SanPham> data;
    public CustomProduct(Context context, int resource, ArrayList<SanPham> data) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.data = data;
    }


    @Override
    public int getCount() {
        return data.size();
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(resource,null);
        ImageView imageView = view.findViewById(R.id.imgV);
        TextView txtMasp = view.findViewById(R.id.cusMasp);
        TextView txtTensp = view.findViewById(R.id.cusTensp);
        TextView txtGia = view.findViewById(R.id.cusGiasp);
        TextView txtDVT = view.findViewById(R.id.cusdvt);

        SanPham sanPham = data.get(position);
        imageView.setImageResource(R.drawable.ic_android_black_24dp);
        txtMasp.setText(sanPham.getMaVatTu());
        txtTensp.setText(sanPham.getTenVatTu());
        txtGia.setText(sanPham.getGia() + "đ");
        txtDVT.setText(" /"+sanPham.getDVT());

        return view;
    }

//    private Filter Prodouctfilter = new Filter() {
//        @Override
//        protected FilterResults performFiltering(CharSequence constraint) {
//            FilterResults results = new FilterResults();
//            ArrayList<SanPham> filtersanpham = new ArrayList<>();
//
//            if(constraint ==null || constraint.length() ==0){
//                filtersanpham.addAll(data);
//            }else{
//                String filterPattern = constraint.toString().toLowerCase().trim();
//                for(SanPham sanPham: data){
//                    if(sanPham.getMaVatTu().toLowerCase().contains(filterPattern)){
//                        filtersanpham.add(sanPham);
//                    }
//                }
//            }
//            results.values = filtersanpham;
//            results.count = filtersanpham.size();
//            return results;
//        }
//
//        @Override
//        protected void publishResults(CharSequence constraint, FilterResults results) {
//            clear();
//            addAll((ArrayList<SanPham>)results.values);
//            notifyDataSetChanged();
//        }

//        @Override
//        public CharSequence convertResultToString(Object resultValue) {
//            return ((SanPham) resultValue).getMaVatTu();
//        }
//    };
}
