package com.example.project1.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project1.Model.SanPham;
import com.example.project1.R;

import java.util.ArrayList;

public class MyRecyclerView extends RecyclerView.Adapter<MyRecyclerView.MyViewHolder> {
    ArrayList<SanPham> data;
    Context context;

    public MyRecyclerView( Context context, ArrayList<SanPham> data) {
        this.data = data;
        this.context = context;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
//        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View Itemview = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_grid,viewGroup ,false);;
        return new MyViewHolder(Itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        SanPham sanPham = data.get(i);
        myViewHolder.imageView.setImageResource(R.drawable.ic_android_black_24dp);
        myViewHolder.txtMasp.setText(sanPham.getMaVatTu());
        myViewHolder.txtTensp.setText(sanPham.getTenVatTu());
        myViewHolder.txtGia.setText(sanPham.getGia()+"");
        myViewHolder.txtDVT.setText(sanPham.getDVT());
    }


    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView txtMasp, txtTensp, txtGia, txtDVT;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
             imageView = itemView.findViewById(R.id.imgV);
             txtMasp = itemView.findViewById(R.id.cusMasp);
             txtTensp = itemView.findViewById(R.id.cusTensp);
             txtGia = itemView.findViewById(R.id.cusGiasp);
             txtDVT = itemView.findViewById(R.id.cusdvt);
        }
    }

}
