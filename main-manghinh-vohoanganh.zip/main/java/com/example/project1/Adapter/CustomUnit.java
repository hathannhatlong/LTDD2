package com.example.project1.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project1.DataBase.UnitManager;
import com.example.project1.Model.DonViTinh;
import com.example.project1.R;

import java.util.ArrayList;

public class CustomUnit extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList <DonViTinh> data;
    public CustomUnit( Context context, int resource, ArrayList <DonViTinh> data) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(resource,null);
        final TextView textView_unit = view.findViewById(R.id.cus_unit);


        final DonViTinh donViTinh = data.get(position);
        textView_unit.setText(donViTinh.getDvt());
        Button btnDelUnit = view.findViewById(R.id.btn_del_unit);
        btnDelUnit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Thông báo");
                builder.setMessage("Bạn có chắc chắn muốn xóa đơn vị tính "+ textView_unit.getText() +"?");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        UnitManager unitManager = new UnitManager(getContext());
                        if(unitManager.Del(textView_unit.getText().toString()) == 0){
                            Toast.makeText(getContext(), "Xóa đơn vị tính thành công!",Toast.LENGTH_LONG).show();
                        }else{
                            Toast.makeText(getContext(), "Đơn vị tính vẫn tồn tại trong sản phẩm. Xóa Thất Bại!",Toast.LENGTH_LONG).show();
                        }

                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });
        return view;
    }
}
